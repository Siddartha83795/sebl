import json
import os
from pathlib import Path
from src.utils.logger import get_logger

class AppConfig:
    """Manages application configuration settings."""
    
    DEFAULT_CONFIG = {
        "app": {
            "name": "Secure MCQ 2025",
            "version": "1.0.0"
        },
        "exam": {
            "time_limit": 30,  # seconds per question
            "shuffle_questions": True,
            "show_results_immediately": False
        },
        "security": {
            "block_keyboard": True,
            "block_network": True,
            "fullscreen": True
        },
        "ui": {
            "theme": "dark",
            "animations": True,
            "font_size": "medium"
        }
    }
    
    CONFIG_FILE = "config.json"
    
    def __init__(self):
        self.logger = get_logger(__name__)
        self.config_dir = Path("data")
        self.config_path = self.config_dir / self.CONFIG_FILE
        self.config = self.load_config()
    
    def load_config(self):
        """Load configuration from file or create default config."""
        self.config_dir.mkdir(exist_ok=True)
        
        if not self.config_path.exists():
            self.logger.info("Config file not found, creating default config")
            self.save_config(self.DEFAULT_CONFIG)
            return self.DEFAULT_CONFIG
        
        try:
            with open(self.config_path, "r") as f:
                config = json.load(f)
                self.logger.info("Config loaded successfully")
                return config
        except Exception as e:
            self.logger.error(f"Error loading config: {str(e)}")
            self.logger.info("Using default config")
            return self.DEFAULT_CONFIG
    
    def save_config(self, config=None):
        """Save configuration to file."""
        if config is None:
            config = self.config
        
        try:
            with open(self.config_path, "w") as f:
                json.dump(config, f, indent=4)
            self.logger.info("Config saved successfully")
            return True
        except Exception as e:
            self.logger.error(f"Error saving config: {str(e)}")
            return False
    
    def get(self, section, key=None):
        """Get a configuration value."""
        try:
            if key is None:
                return self.config.get(section, {})
            return self.config.get(section, {}).get(key)
        except:
            # If anything goes wrong, return the default value
            if key is None:
                return self.DEFAULT_CONFIG.get(section, {})
            return self.DEFAULT_CONFIG.get(section, {}).get(key)
    
    def set(self, section, key, value):
        """Set a configuration value."""
        if section not in self.config:
            self.config[section] = {}
        
        self.config[section][key] = value
        return self.save_config()
    
    def reset_to_defaults(self):
        """Reset configuration to default values."""
        self.config = self.DEFAULT_CONFIG.copy()
        return self.save_config()