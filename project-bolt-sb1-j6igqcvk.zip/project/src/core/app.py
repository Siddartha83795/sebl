import tkinter as tk
from tkinter import ttk
import sys
import os
from threading import Thread

# Import application modules
from src.core.database import DatabaseManager
from src.core.config import AppConfig
from src.ui.theme import ThemeManager
from src.ui.login import LoginScreen
from src.ui.student_dashboard import StudentDashboard
from src.ui.staff_dashboard import StaffDashboard
from src.ui.exam import ExamScreen
from src.ui.results import ResultScreen
from src.utils.logger import get_logger
from src.utils.security import SecurityManager

class SecureMCQApp:
    """Main application class that manages the application lifecycle."""
    
    def __init__(self):
        self.logger = get_logger(__name__)
        self.logger.info("Initializing application")
        
        # Create the root window
        self.root = tk.Tk()
        self.root.title("MCQ Tester 2025")
        self.root.geometry("1280x720")
        self.root.minsize(800, 600)
        
        # Set application icon
        try:
            if os.path.exists("assets/icon.png"):
                icon = tk.PhotoImage(file="assets/icon.png")
                self.root.iconphoto(True, icon)
        except Exception as e:
            self.logger.error(f"Failed to load application icon: {str(e)}")
        
        # Initialize application configuration
        self.config = AppConfig()
        
        # Initialize theme manager
        self.theme_manager = ThemeManager(self.root)
        self.theme_manager.apply_theme()
        
        # Initialize database manager
        self.db = DatabaseManager()
        
        # Initialize security manager
        self.security_manager = SecurityManager(self.root)
        
        # Initialize UI screens
        self.screens = {
            'login': None,
            'student_dashboard': None,
            'staff_dashboard': None,
            'exam': None,
            'results': None
        }
        
        # Application state
        self.current_user = None
        self.current_screen = None
        
        # Handle window close
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        
        # Create loading screen
        self.show_loading_screen()

    def show_loading_screen(self):
        """Display a loading screen while initializing the application."""
        loading_frame = ttk.Frame(self.root)
        loading_frame.pack(fill="both", expand=True)
        
        loading_label = ttk.Label(
            loading_frame, 
            text="Loading Secure MCQ 2025...",
            font=("Roboto", 20, "bold")
        )
        loading_label.pack(expand=True)
        
        # Initialize database and other components in a separate thread
        Thread(target=self.initialize_app, daemon=True).start()
        
        # Update UI while initializing
        self.root.update()
    
    def initialize_app(self):
        """Initialize application components in a background thread."""
        try:
            # Initialize database
            self.db.initialize()
            
            # Initialize screens
            self.screens['login'] = LoginScreen(self.root, self)
            self.screens['student_dashboard'] = StudentDashboard(self.root, self)
            self.screens['staff_dashboard'] = StaffDashboard(self.root, self)
            self.screens['exam'] = ExamScreen(self.root, self)
            self.screens['results'] = ResultScreen(self.root, self)
            
            # Show login screen
            self.root.after(0, self.show_login)
        except Exception as e:
            self.logger.error(f"Initialization error: {str(e)}")
            self.root.after(0, lambda: self.show_error(f"Initialization failed: {str(e)}"))
    
    def show_login(self):
        """Display the login screen."""
        self.clear_screen()
        self.screens['login'].show()
        self.current_screen = 'login'
    
    def show_student_dashboard(self):
        """Display the student dashboard."""
        self.clear_screen()
        self.screens['student_dashboard'].show(self.current_user)
        self.current_screen = 'student_dashboard'
    
    def show_staff_dashboard(self):
        """Display the staff dashboard."""
        self.clear_screen()
        self.screens['staff_dashboard'].show(self.current_user)
        self.current_screen = 'staff_dashboard'
    
    def show_exam(self, subject):
        """Display the exam screen."""
        self.clear_screen()
        self.screens['exam'].start_exam(self.current_user, subject)
        self.current_screen = 'exam'
    
    def show_results(self, results=None, exam_data=None):
        """Display the results screen."""
        self.clear_screen()
        self.screens['results'].show(self.current_user, results, exam_data)
        self.current_screen = 'results'
    
    def clear_screen(self):
        """Clear the current screen."""
        for widget in self.root.winfo_children():
            widget.pack_forget()
    
    def show_error(self, message):
        """Display an error message."""
        self.logger.error(message)
        tk.messagebox.showerror("Error", message)
    
    def set_current_user(self, user):
        """Set the current user and navigate to appropriate dashboard."""
        self.current_user = user
        self.logger.info(f"User logged in: {user['name']} ({user['role']})")
        
        if user['role'] == 'student':
            self.show_student_dashboard()
        else:
            self.show_staff_dashboard()
    
    def logout(self):
        """Log out the current user."""
        if self.current_user:
            self.logger.info(f"User logged out: {self.current_user['name']}")
            self.current_user = None
            self.security_manager.disable_secure_mode()
            self.show_login()
    
    def on_close(self):
        """Handle window close event."""
        if self.security_manager.is_exam_mode():
            tk.messagebox.showwarning("Warning", "Cannot close during exam!")
        else:
            self.logger.info("Application shutting down")
            try:
                self.db.close()
            except:
                pass
            self.root.destroy()
    
    def start(self):
        """Start the application main loop."""
        self.logger.info("Starting main application loop")
        self.root.mainloop()