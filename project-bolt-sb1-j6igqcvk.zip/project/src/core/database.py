import sqlite3
import os
import hashlib
import datetime
from pathlib import Path
import pandas as pd
from src.utils.logger import get_logger

class DatabaseManager:
    """
    Manages all database operations for the MCQ application.
    """
    
    DB_NAME = "secure_mcq.db"
    
    def __init__(self):
        self.logger = get_logger(__name__)
        self.logger.info("Initializing database manager")
        
        # Ensure the data directory exists
        data_dir = Path("data")
        data_dir.mkdir(exist_ok=True)
        
        self.db_path = data_dir / self.DB_NAME
        self.conn = None
        self.cursor = None
    
    def initialize(self):
        """Initialize the database connection and create tables if needed."""
        try:
            self.conn = sqlite3.connect(self.db_path)
            self.cursor = self.conn.cursor()
            self.create_tables()
            return True
        except sqlite3.Error as e:
            self.logger.error(f"Database initialization error: {str(e)}")
            raise
    
    def create_tables(self):
        """Create database tables if they don't exist."""
        tables = [
            '''CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                role TEXT NOT NULL,
                section TEXT,
                usn TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_login TIMESTAMP)''',
            
            '''CREATE TABLE IF NOT EXISTS questions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                subject TEXT NOT NULL,
                question TEXT NOT NULL,
                option_a TEXT NOT NULL,
                option_b TEXT NOT NULL,
                option_c TEXT NOT NULL,
                option_d TEXT NOT NULL,
                correct TEXT NOT NULL,
                image_path TEXT,
                created_by INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (created_by) REFERENCES users (id))''',
            
            '''CREATE TABLE IF NOT EXISTS results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                usn TEXT NOT NULL,
                subject TEXT NOT NULL,
                score INTEGER NOT NULL,
                total INTEGER NOT NULL,
                duration INTEGER,
                date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id))''',
                
            '''CREATE TABLE IF NOT EXISTS user_responses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                result_id INTEGER NOT NULL,
                question_id INTEGER NOT NULL,
                user_answer TEXT,
                is_correct BOOLEAN,
                time_taken INTEGER,
                FOREIGN KEY (result_id) REFERENCES results (id),
                FOREIGN KEY (question_id) REFERENCES questions (id))'''
        ]
        
        for table in tables:
            try:
                self.cursor.execute(table)
            except sqlite3.Error as e:
                self.logger.error(f"Error creating table: {str(e)}")
                raise
        
        self.conn.commit()
        self.logger.info("Database tables created successfully")
    
    def close(self):
        """Close the database connection."""
        if self.conn:
            self.conn.close()
            self.logger.info("Database connection closed")
    
    def hash_password(self, password):
        """Hash a password using SHA-256."""
        return hashlib.sha256(password.encode()).hexdigest()
    
    # User management methods
    def authenticate_user(self, usn, password, role):
        """Authenticate a user with the given credentials."""
        try:
            hashed_password = self.hash_password(password)
            self.cursor.execute(
                "SELECT id, name, role, section, usn FROM users WHERE usn=? AND password=? AND role=?", 
                (usn, hashed_password, role)
            )
            user = self.cursor.fetchone()
            
            if user:
                # Update last login time
                self.cursor.execute(
                    "UPDATE users SET last_login=? WHERE id=?",
                    (datetime.datetime.now().isoformat(), user[0])
                )
                self.conn.commit()
                
                return {
                    'id': user[0],
                    'name': user[1],
                    'role': user[2],
                    'section': user[3],
                    'usn': user[4]
                }
            return None
        except sqlite3.Error as e:
            self.logger.error(f"Authentication error: {str(e)}")
            return None
    
    def add_user(self, name, role, usn, password, section=None):
        """Add a new user to the database."""
        try:
            hashed_password = self.hash_password(password)
            self.cursor.execute(
                "INSERT INTO users (name, role, section, usn, password) VALUES (?, ?, ?, ?, ?)",
                (name, role, section, usn, hashed_password)
            )
            self.conn.commit()
            return True
        except sqlite3.IntegrityError:
            self.logger.warning(f"User already exists: {usn}")
            return False
        except sqlite3.Error as e:
            self.logger.error(f"Error adding user: {str(e)}")
            return False
    
    def import_students_from_excel(self, file_path):
        """Import students from an Excel file."""
        try:
            df = pd.read_excel(file_path)
            required_cols = ['Name', 'USN', 'Section', 'Password']
            
            if not all(col in df.columns for col in required_cols):
                return False, "Missing required columns in Excel file"
            
            success_count = 0
            failed_count = 0
            
            for _, row in df.iterrows():
                try:
                    success = self.add_user(
                        name=row['Name'],
                        role='student',
                        usn=row['USN'],
                        password=row['Password'],
                        section=row['Section']
                    )
                    if success:
                        success_count += 1
                    else:
                        failed_count += 1
                except Exception as e:
                    self.logger.error(f"Error importing student: {str(e)}")
                    failed_count += 1
            
            return True, f"Successfully imported {success_count} students. Failed: {failed_count}"
        except Exception as e:
            self.logger.error(f"Error importing students: {str(e)}")
            return False, f"Import failed: {str(e)}"
    
    # Question management methods
    def add_question(self, subject, question, options, correct, image_path=None, created_by=None):
        """Add a new question to the database."""
        try:
            self.cursor.execute(
                """INSERT INTO questions 
                   (subject, question, option_a, option_b, option_c, option_d, correct, image_path, created_by) 
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    subject.lower(),
                    question,
                    options[0],
                    options[1],
                    options[2],
                    options[3],
                    correct.upper(),
                    image_path,
                    created_by
                )
            )
            self.conn.commit()
            return True
        except sqlite3.Error as e:
            self.logger.error(f"Error adding question: {str(e)}")
            return False
    
    def import_questions_from_excel(self, file_path, created_by=None):
        """Import questions from an Excel file."""
        try:
            df = pd.read_excel(file_path)
            required_cols = ['Subject', 'Question', 'Option A', 'Option B', 'Option C', 'Option D', 'Correct']
            
            if not all(col in df.columns for col in required_cols):
                return False, "Missing required columns in Excel file"
            
            has_image = 'Image Path' in df.columns
            success_count = 0
            failed_count = 0
            
            for _, row in df.iterrows():
                try:
                    options = [row['Option A'], row['Option B'], row['Option C'], row['Option D']]
                    image_path = row['Image Path'] if has_image and pd.notna(row['Image Path']) else None
                    
                    success = self.add_question(
                        subject=row['Subject'],
                        question=row['Question'],
                        options=options,
                        correct=row['Correct'],
                        image_path=image_path,
                        created_by=created_by
                    )
                    
                    if success:
                        success_count += 1
                    else:
                        failed_count += 1
                except Exception as e:
                    self.logger.error(f"Error importing question: {str(e)}")
                    failed_count += 1
            
            return True, f"Successfully imported {success_count} questions. Failed: {failed_count}"
        except Exception as e:
            self.logger.error(f"Error importing questions: {str(e)}")
            return False, f"Import failed: {str(e)}"
    
    def get_questions_by_subject(self, subject):
        """Get all questions for a specific subject."""
        try:
            self.cursor.execute(
                "SELECT * FROM questions WHERE subject=? ORDER BY id",
                (subject.lower(),)
            )
            questions = self.cursor.fetchall()
            return questions
        except sqlite3.Error as e:
            self.logger.error(f"Error getting questions: {str(e)}")
            return []
    
    def get_subjects(self):
        """Get a list of all subjects that have questions."""
        try:
            self.cursor.execute("SELECT DISTINCT subject FROM questions ORDER BY subject")
            subjects = [row[0] for row in self.cursor.fetchall()]
            return subjects
        except sqlite3.Error as e:
            self.logger.error(f"Error getting subjects: {str(e)}")
            return []
    
    # Results management methods
    def save_result(self, user_id, usn, subject, score, total, duration=None):
        """Save an exam result to the database."""
        try:
            self.cursor.execute(
                "INSERT INTO results (user_id, usn, subject, score, total, duration) VALUES (?, ?, ?, ?, ?, ?)",
                (user_id, usn, subject, score, total, duration)
            )
            self.conn.commit()
            return self.cursor.lastrowid
        except sqlite3.Error as e:
            self.logger.error(f"Error saving result: {str(e)}")
            return None
    
    def save_user_responses(self, result_id, responses):
        """Save detailed user responses for an exam."""
        try:
            for response in responses:
                self.cursor.execute(
                    """INSERT INTO user_responses 
                       (result_id, question_id, user_answer, is_correct, time_taken) 
                       VALUES (?, ?, ?, ?, ?)""",
                    (
                        result_id,
                        response['question_id'],
                        response['user_answer'],
                        response['is_correct'],
                        response['time_taken']
                    )
                )
            self.conn.commit()
            return True
        except sqlite3.Error as e:
            self.logger.error(f"Error saving user responses: {str(e)}")
            return False
    
    def get_results_by_user(self, usn):
        """Get all results for a specific user."""
        try:
            self.cursor.execute(
                """SELECT id, subject, score, total, duration, date 
                   FROM results WHERE usn=? ORDER BY date DESC""",
                (usn,)
            )
            return self.cursor.fetchall()
        except sqlite3.Error as e:
            self.logger.error(f"Error getting results: {str(e)}")
            return []
    
    def get_all_results(self):
        """Get all exam results."""
        try:
            self.cursor.execute(
                """SELECT r.id, u.name, r.usn, r.subject, r.score, r.total, r.date 
                   FROM results r JOIN users u ON r.user_id = u.id 
                   ORDER BY r.date DESC"""
            )
            return self.cursor.fetchall()
        except sqlite3.Error as e:
            self.logger.error(f"Error getting all results: {str(e)}")
            return []