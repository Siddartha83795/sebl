import tkinter as tk
from tkinter import ttk, messagebox
from src.utils.logger import get_logger
from src.ui.components.glass_frame import GlassFrame
from src.ui.components.animated import create_fade_in_effect

class StaffRegistrationScreen:
    """Staff registration screen."""
    
    def __init__(self, root, app):
        self.logger = get_logger(__name__)
        self.root = root
        self.app = app
        self.frame = None
    
    def show(self):
        """Display the staff registration screen."""
        self.logger.info("Showing staff registration screen")
        
        # Clear existing widgets
        for widget in self.root.winfo_children():
            widget.pack_forget()
        
        # Create main frame
        self.frame = ttk.Frame(self.root)
        self.frame.pack(fill="both", expand=True)
        
        # Create a background with gradient
        theme = self.app.theme_manager.current_theme
        bg_gradient = self.app.theme_manager.create_gradient_canvas(
            self.frame, 
            self.root.winfo_width(), 
            self.root.winfo_height(),
            theme["bg"], 
            theme["accent"],
            "vertical"
        )
        bg_gradient.place(x=0, y=0, relwidth=1, relheight=1)
        
        # Registration container
        reg_container = GlassFrame(self.frame, opacity=0.2)
        reg_container.place(relx=0.5, rely=0.5, anchor="center", relwidth=0.5, relheight=0.7)
        
        # Registration heading
        reg_heading = ttk.Label(
            reg_container, 
            text="Staff Registration",
            style="Heading.TLabel"
        )
        reg_heading.pack(pady=(30, 10))
        
        # Registration subtitle
        reg_subtitle = ttk.Label(
            reg_container, 
            text="Create a new staff account",
            style="Subtext.TLabel"
        )
        reg_subtitle.pack(pady=(0, 20))
        
        # Create form fields
        form_frame = ttk.Frame(reg_container)
        form_frame.pack(pady=10, padx=50, fill="x")
        
        # Form fields
        fields = [
            ("Full Name", "name", ""),
            ("Staff ID", "usn", ""),
            ("Password", "password", "•"),
            ("Confirm Password", "confirm_password", "•")
        ]
        
        self.entries = {}
        
        for label, field, show in fields:
            field_frame = ttk.Frame(form_frame)
            field_frame.pack(fill="x", pady=10)
            
            ttk.Label(field_frame, text=f"{label}:").pack(anchor="w", pady=(0, 5))
            entry = ttk.Entry(field_frame, font=("Roboto", 12), show=show)
            entry.pack(fill="x")
            self.entries[field] = entry
        
        # Action buttons
        button_frame = ttk.Frame(reg_container)
        button_frame.pack(pady=20)
        
        # Register button
        register_button = ttk.Button(
            button_frame,
            text="Complete Registration",
            style="Primary.TButton",
            command=self.register_staff
        )
        register_button.pack(side=tk.LEFT, padx=10, ipadx=10, ipady=5)
        
        # Back button
        back_button = ttk.Button(
            button_frame,
            text="Back to Login",
            command=self.app.show_login
        )
        back_button.pack(side=tk.LEFT, padx=10, ipadx=10, ipady=5)
        
        # Apply fade-in effect
        create_fade_in_effect(reg_container)
    
    def register_staff(self):
        """Register a new staff member."""
        # Get form data
        data = {k: v.get() for k, v in self.entries.items()}
        
        # Validate input
        if not all(data.values()):
            messagebox.showwarning("Input Error", "All fields are required")
            return
        
        if data['password'] != data['confirm_password']:
            messagebox.showwarning("Input Error", "Passwords do not match")
            return
        
        # Attempt to register
        success = self.app.db.add_user(
            name=data['name'],
            role='staff',
            usn=data['usn'],
            password=data['password']
        )
        
        if success:
            self.logger.info(f"Staff registered: {data['name']}")
            messagebox.showinfo("Success", "Staff registration successful")
            self.app.show_login()
        else:
            messagebox.showerror("Registration Error", "Staff ID may already exist or there was a database error")