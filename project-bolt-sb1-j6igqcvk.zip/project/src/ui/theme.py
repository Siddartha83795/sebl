from tkinter import ttk
import tkinter as tk
from src.utils.logger import get_logger

class ThemeManager:
    """Manages application themes and styles."""
    
    THEMES = {
        "dark": {
            "bg": "#1E1E2E",
            "fg": "#FFFFFF",
            "accent": "#7E57C2",
            "accent_hover": "#9575CD",
            "success": "#66BB6A",
            "warning": "#FFCA28",
            "error": "#EF5350",
            "card_bg": "#2E2E42",
            "input_bg": "#383851",
            "button_bg": "#7E57C2",
            "button_fg": "#FFFFFF",
            "disabled_bg": "#4E4E63",
            "disabled_fg": "#9E9EAA",
            "heading_fg": "#FFFFFF",
            "subtext_fg": "#B3B3CC",
            "border": "#4E4E63",
            "hover_bg": "#3E3E56",
            "font": ("Roboto", 10),
            "heading_font": ("Roboto", 16, "bold"),
            "button_font": ("Roboto", 10, "bold")
        },
        "light": {
            "bg": "#F5F5F7",
            "fg": "#333333",
            "accent": "#6D56C1",
            "accent_hover": "#8A75D2",
            "success": "#4CAF50",
            "warning": "#FF9800",
            "error": "#F44336",
            "card_bg": "#FFFFFF",
            "input_bg": "#EBEBEB",
            "button_bg": "#6D56C1",
            "button_fg": "#FFFFFF",
            "disabled_bg": "#D8D8D8",
            "disabled_fg": "#999999",
            "heading_fg": "#222222",
            "subtext_fg": "#666666",
            "border": "#CCCCCC",
            "hover_bg": "#E8E8EC",
            "font": ("Roboto", 10),
            "heading_font": ("Roboto", 16, "bold"),
            "button_font": ("Roboto", 10, "bold")
        }
    }
    
    def __init__(self, root, theme_name="dark"):
        self.logger = get_logger(__name__)
        self.root = root
        self.theme_name = theme_name
        self.theme = self.THEMES[theme_name]
        
        try:
            # Try to import ttkthemes if available
            import ttkthemes
            self.use_ttkthemes = True
        except ImportError:
            self.logger.warning("ttkthemes not found, using standard ttk styling")
            self.use_ttkthemes = False
    
    def apply_theme(self):
        """Apply the selected theme to the application."""
        self.logger.info(f"Applying theme: {self.theme_name}")
        
        if self.use_ttkthemes:
            try:
                from ttkthemes import ThemedStyle
                style = ThemedStyle(self.root)
                # Use dark 'equilux' theme as a base for dark mode, or 'arc' for light mode
                style.set_theme("equilux" if self.theme_name == "dark" else "arc")
            except Exception as e:
                self.logger.error(f"Error applying ttkthemes: {str(e)}")
                style = ttk.Style()
        else:
            style = ttk.Style()
        
        # Configure general styles
        self.root.configure(bg=self.theme["bg"])
        style.configure(".", 
                       background=self.theme["bg"],
                       foreground=self.theme["fg"],
                       font=self.theme["font"],
                       borderwidth=0)
        
        # Configure TFrame
        style.configure("TFrame", background=self.theme["bg"])
        
        # Configure TLabel
        style.configure("TLabel", 
                       background=self.theme["bg"],
                       foreground=self.theme["fg"],
                       font=self.theme["font"])
        
        # Heading label style
        style.configure("Heading.TLabel",
                       font=self.theme["heading_font"],
                       foreground=self.theme["heading_fg"])
        
        # Subtext label style
        style.configure("Subtext.TLabel",
                       foreground=self.theme["subtext_fg"])
        
        # Configure TButton
        style.configure("TButton",
                       background=self.theme["button_bg"],
                       foreground=self.theme["button_fg"],
                       font=self.theme["button_font"],
                       padding=(10, 5),
                       borderwidth=0)
        
        style.map("TButton",
                 background=[("active", self.theme["accent_hover"]),
                            ("disabled", self.theme["disabled_bg"])],
                 foreground=[("disabled", self.theme["disabled_fg"])])
        
        # Primary button style
        style.configure("Primary.TButton",
                       background=self.theme["accent"],
                       foreground=self.theme["button_fg"])
        
        style.map("Primary.TButton",
                 background=[("active", self.theme["accent_hover"])])
        
        # Success button style
        style.configure("Success.TButton",
                       background=self.theme["success"],
                       foreground=self.theme["button_fg"])
        
        # Warning button style
        style.configure("Warning.TButton",
                       background=self.theme["warning"],
                       foreground=self.theme["button_fg"])
        
        # Error button style
        style.configure("Error.TButton",
                       background=self.theme["error"],
                       foreground=self.theme["button_fg"])
        
        # Configure TEntry
        style.configure("TEntry",
                       fieldbackground=self.theme["input_bg"],
                       foreground=self.theme["fg"],
                       padding=5,
                       borderwidth=1,
                       relief="solid",
                       bordercolor=self.theme["border"])
        
        # Configure TCombobox
        style.configure("TCombobox",
                       fieldbackground=self.theme["input_bg"],
                       background=self.theme["button_bg"],
                       foreground=self.theme["fg"],
                       arrowcolor=self.theme["fg"],
                       padding=5)
        
        # Configure Treeview
        style.configure("Treeview",
                       background=self.theme["card_bg"],
                       foreground=self.theme["fg"],
                       fieldbackground=self.theme["card_bg"],
                       borderwidth=0)
        
        style.configure("Treeview.Heading",
                       background=self.theme["accent"],
                       foreground=self.theme["button_fg"],
                       font=self.theme["button_font"],
                       relief="flat")
        
        style.map("Treeview",
                 background=[("selected", self.theme["accent"])],
                 foreground=[("selected", self.theme["button_fg"])])
        
        # Card frame style
        style.configure("Card.TFrame",
                       background=self.theme["card_bg"],
                       relief="raised",
                       borderwidth=0)
        
        # Configure TCheckbutton and TRadiobutton
        style.configure("TCheckbutton",
                       background=self.theme["bg"],
                       foreground=self.theme["fg"])
        
        style.configure("TRadiobutton",
                       background=self.theme["bg"],
                       foreground=self.theme["fg"])
        
        # Configure TProgressbar
        style.configure("TProgressbar",
                       background=self.theme["accent"],
                       troughcolor=self.theme["bg"])
        
        # Configure TNotebook
        style.configure("TNotebook",
                       background=self.theme["bg"],
                       tabmargins=[0, 0, 0, 0])
        
        style.configure("TNotebook.Tab",
                       background=self.theme["card_bg"],
                       foreground=self.theme["fg"],
                       padding=[10, 5],
                       font=self.theme["font"])
        
        style.map("TNotebook.Tab",
                 background=[("selected", self.theme["accent"])],
                 foreground=[("selected", self.theme["button_fg"])])
        
        self.logger.info("Theme applied successfully")
    
    def create_gradient_canvas(self, parent, width, height, color1, color2, orientation="horizontal"):
        """Create a canvas with a gradient background."""
        canvas = tk.Canvas(parent, width=width, height=height, highlightthickness=0)
        
        if orientation == "horizontal":
            for i in range(width):
                # Calculate color components
                r1, g1, b1 = parent.winfo_rgb(color1)
                r2, g2, b2 = parent.winfo_rgb(color2)
                
                # Interpolate between the colors
                ratio = i / width
                r = int(r1 * (1 - ratio) + r2 * ratio) // 256
                g = int(g1 * (1 - ratio) + g2 * ratio) // 256
                b = int(b1 * (1 - ratio) + b2 * ratio) // 256
                
                # Create the line with the calculated color
                color = f'#{r:02x}{g:02x}{b:02x}'
                canvas.create_line(i, 0, i, height, fill=color)
        else:
            for i in range(height):
                # Calculate color components
                r1, g1, b1 = parent.winfo_rgb(color1)
                r2, g2, b2 = parent.winfo_rgb(color2)
                
                # Interpolate between the colors
                ratio = i / height
                r = int(r1 * (1 - ratio) + r2 * ratio) // 256
                g = int(g1 * (1 - ratio) + g2 * ratio) // 256
                b = int(b1 * (1 - ratio) + b2 * ratio) // 256
                
                # Create the line with the calculated color
                color = f'#{r:02x}{g:02x}{b:02x}'
                canvas.create_line(0, i, width, i, fill=color)
        
        return canvas
    
    def switch_theme(self, theme_name):
        """Switch to a different theme."""
        if theme_name in self.THEMES:
            self.theme_name = theme_name
            self.theme = self.THEMES[theme_name]
            self.apply_theme()
            return True
        return False
    
    @property
    def current_theme(self):
        """Get the current theme."""
        return self.theme