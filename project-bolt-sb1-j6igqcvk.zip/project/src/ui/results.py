import tkinter as tk
from tkinter import ttk
import time
from src.utils.logger import get_logger
from src.ui.components.glass_frame import GlassFrame
from src.ui.components.animated import create_fade_in_effect

class ResultScreen:
    """Results screen for displaying exam results."""
    
    def __init__(self, root, app):
        self.logger = get_logger(__name__)
        self.root = root
        self.app = app
        self.frame = None
        self.user = None
    
    def show(self, user, results=None, exam_data=None):
        """Display the results screen."""
        self.logger.info(f"Showing results for: {user['name']}")
        self.user = user
        
        # Create main frame
        self.frame = ttk.Frame(self.root)
        self.frame.pack(fill="both", expand=True)
        
        # Create a background with gradient
        theme = self.app.theme_manager.current_theme
        bg_gradient = self.app.theme_manager.create_gradient_canvas(
            self.frame, 
            self.root.winfo_width(), 
            self.root.winfo_height(),
            theme["bg"], 
            theme["success"] if exam_data and exam_data['correct_answers'] / exam_data['total_questions'] >= 0.6 else theme["error"],
            "vertical"
        )
        bg_gradient.place(x=0, y=0, relwidth=1, relheight=1)
        
        # If exam_data is provided, show exam results
        if exam_data:
            self.show_exam_results(exam_data)
        # Otherwise, show results history
        else:
            self.show_results_history(results)
    
    def show_exam_results(self, exam_data):
        """Show results for a completed exam."""
        # Header
        header_frame = GlassFrame(self.frame, opacity=0.1)
        header_frame.place(x=0, y=0, relwidth=1, height=80)
        
        # Add confetti effect for good scores
        score_percentage = exam_data['correct_answers'] / exam_data['total_questions']
        
        if score_percentage >= 0.7:
            self.add_confetti_effect()
        
        # Result heading
        result_heading = ttk.Label(
            header_frame,
            text="Assessment Completed!",
            font=("Roboto", 20, "bold")
        )
        result_heading.pack(pady=(20, 0))
        
        # Results container
        results_container = GlassFrame(self.frame, opacity=0.2)
        results_container.place(relx=0.5, rely=0.45, anchor="center", relwidth=0.8, relheight=0.65)
        
        # Summary section
        summary_frame = ttk.Frame(results_container)
        summary_frame.pack(fill="x", pady=20, padx=30)
        
        # Student info
        student_info = ttk.Label(
            summary_frame,
            text=f"Name: {self.user['name']}  |  USN: {self.user['usn']}",
            font=("Roboto", 12)
        )
        student_info.pack(anchor="w", pady=(0, 10))
        
        # Subject and date
        subject_date = ttk.Label(
            summary_frame,
            text=f"Subject: {exam_data['subject'].capitalize()}  |  Date: {time.strftime('%Y-%m-%d %H:%M')}",
            font=("Roboto", 12)
        )
        subject_date.pack(anchor="w", pady=(0, 20))
        
        # Score information
        score_frame = ttk.Frame(summary_frame)
        score_frame.pack(fill="x", pady=10)
        
        # Score heading
        score_heading = ttk.Label(
            score_frame,
            text="SCORE",
            font=("Roboto", 16, "bold")
        )
        score_heading.pack(anchor="w")
        
        # Horizontal separator
        ttk.Separator(score_frame, orient="horizontal").pack(fill="x", pady=10)
        
        # Score details
        score_details_frame = ttk.Frame(score_frame)
        score_details_frame.pack(fill="x", pady=10)
        
        # Format duration
        minutes, seconds = divmod(exam_data['duration'], 60)
        duration_str = f"{minutes}m {seconds}s"
        
        # Calculate percentage
        percentage = (exam_data['correct_answers'] / exam_data['total_questions']) * 100
        
        # Score details
        details = [
            ("Correct Answers:", f"{exam_data['correct_answers']} / {exam_data['total_questions']}"),
            ("Percentage:", f"{percentage:.1f}%"),
            ("Time Taken:", duration_str)
        ]
        
        for label, value in details:
            detail_frame = ttk.Frame(score_details_frame)
            detail_frame.pack(fill="x", pady=5)
            
            ttk.Label(
                detail_frame,
                text=label,
                font=("Roboto", 12, "bold"),
                width=20
            ).pack(side=tk.LEFT)
            
            ttk.Label(
                detail_frame,
                text=value,
                font=("Roboto", 12)
            ).pack(side=tk.LEFT, padx=10)
        
        # Result grade
        grade_frame = ttk.Frame(summary_frame)
        grade_frame.pack(fill="x", pady=(20, 10))
        
        # Determine grade based on percentage
        grade, grade_color = self.get_grade(percentage)
        
        grade_label = ttk.Label(
            grade_frame,
            text="Grade:",
            font=("Roboto", 14, "bold")
        )
        grade_label.pack(side=tk.LEFT)
        
        grade_value = ttk.Label(
            grade_frame,
            text=grade,
            font=("Roboto", 14, "bold"),
            foreground=grade_color
        )
        grade_value.pack(side=tk.LEFT, padx=10)
        
        # Action buttons
        button_frame = ttk.Frame(self.frame)
        button_frame.place(relx=0.5, rely=0.9, anchor="center")
        
        back_button = ttk.Button(
            button_frame,
            text="Back to Dashboard",
            style="Primary.TButton",
            command=self.app.show_student_dashboard
        )
        back_button.pack(side=tk.LEFT, padx=10)
        
        # Apply fade-in effect
        create_fade_in_effect(results_container)
    
    def show_results_history(self, results):
        """Show history of past results."""
        # Header
        header_frame = GlassFrame(self.frame, opacity=0.1)
        header_frame.place(x=0, y=0, relwidth=1, height=80)
        
        # Heading
        history_heading = ttk.Label(
            header_frame,
            text="Assessment Results History",
            font=("Roboto", 20, "bold")
        )
        history_heading.pack(pady=(20, 0))
        
        # Results container
        history_container = GlassFrame(self.frame, opacity=0.2)
        history_container.place(relx=0.5, rely=0.45, anchor="center", relwidth=0.8, relheight=0.65)
        
        # Results content
        content_frame = ttk.Frame(history_container)
        content_frame.pack(fill="both", expand=True, padx=30, pady=30)
        
        # If no results available
        if not results or len(results) == 0:
            no_results = ttk.Label(
                content_frame,
                text="No assessment results available.",
                font=("Roboto", 14)
            )
            no_results.pack(pady=50)
        else:
            # Create table for results
            table_frame = ttk.Frame(content_frame)
            table_frame.pack(fill="both", expand=True)
            
            # Create treeview
            columns = ("subject", "score", "percentage", "date")
            tree = ttk.Treeview(
                table_frame,
                columns=columns,
                show="headings",
                height=10
            )
            
            # Define column headings
            tree.heading("subject", text="Subject")
            tree.heading("score", text="Score")
            tree.heading("percentage", text="Percentage")
            tree.heading("date", text="Date")
            
            # Define column widths
            tree.column("subject", width=150)
            tree.column("score", width=100)
            tree.column("percentage", width=100)
            tree.column("date", width=150)
            
            # Add scrollbar
            scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
            tree.configure(yscrollcommand=scrollbar.set)
            scrollbar.pack(side=tk.RIGHT, fill="y")
            tree.pack(side=tk.LEFT, fill="both", expand=True)
            
            # Add data to the table
            for result in results:
                result_id = result[0]
                subject = result[1].capitalize()
                score = result[2]
                total = result[3]
                percentage = f"{(score/total)*100:.1f}%"
                date = result[5]
                
                tree.insert(
                    "",
                    "end",
                    values=(subject, f"{score}/{total}", percentage, date),
                    tags=(result_id,)
                )
        
        # Action buttons
        button_frame = ttk.Frame(self.frame)
        button_frame.place(relx=0.5, rely=0.9, anchor="center")
        
        back_button = ttk.Button(
            button_frame,
            text="Back to Dashboard",
            style="Primary.TButton",
            command=self.app.show_student_dashboard
        )
        back_button.pack(side=tk.LEFT, padx=10)
        
        # Apply fade-in effect
        create_fade_in_effect(history_container)
    
    def get_grade(self, percentage):
        """Determine grade based on percentage."""
        theme = self.app.theme_manager.current_theme
        
        if percentage >= 90:
            return "A+", theme["success"]
        elif percentage >= 80:
            return "A", theme["success"]
        elif percentage >= 70:
            return "B", theme["success"]
        elif percentage >= 60:
            return "C", theme["warning"]
        elif percentage >= 50:
            return "D", theme["warning"]
        else:
            return "F", theme["error"]
    
    def add_confetti_effect(self):
        """Add a confetti celebration effect for good scores."""
        import random
        
        canvas = tk.Canvas(
            self.frame, 
            width=self.root.winfo_width(), 
            height=self.root.winfo_height(),
            highlightthickness=0,
            bg="transparent"
        )
        canvas.place(x=0, y=0, relwidth=1, relheight=1)
        
        # Colors for confetti
        colors = ["#FF5252", "#FFD740", "#64FFDA", "#448AFF", "#B388FF", "#FFAB40"]
        
        # Create confetti particles
        particles = []
        for _ in range(100):
            x = random.randint(0, self.root.winfo_width())
            y = random.randint(-self.root.winfo_height(), 0)
            size = random.randint(5, 15)
            color = random.choice(colors)
            speed = random.uniform(1, 5)
            angle = random.uniform(-0.5, 0.5)
            
            particle = canvas.create_rectangle(
                x, y, x+size, y+size,
                fill=color, outline="",
                tags=("confetti",)
            )
            
            particles.append({
                "id": particle,
                "x": x,
                "y": y,
                "size": size,
                "speed": speed,
                "angle": angle
            })
        
        def animate_confetti():
            still_visible = False
            
            for p in particles:
                # Update position
                p["y"] += p["speed"]
                p["x"] += p["angle"]
                
                # Move the particle
                canvas.move(p["id"], p["angle"], p["speed"])
                
                # Check if particle is still visible
                if p["y"] < self.root.winfo_height() + 50:
                    still_visible = True
            
            if still_visible:
                self.root.after(30, animate_confetti)
            else:
                canvas.delete("confetti")
                canvas.destroy()
        
        # Start animation
        animate_confetti()