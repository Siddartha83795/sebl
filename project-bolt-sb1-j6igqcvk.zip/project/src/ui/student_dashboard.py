import tkinter as tk
from tkinter import ttk, messagebox
from src.utils.logger import get_logger
from src.ui.components.glass_frame import GlassFrame
from src.ui.components.animated import AnimatedLabel, create_fade_in_effect
import time

class StudentDashboard:
    """Dashboard for student users."""
    
    def __init__(self, root, app):
        self.logger = get_logger(__name__)
        self.root = root
        self.app = app
        self.frame = None
        self.user = None
    
    def show(self, user):
        """Display the student dashboard."""
        self.logger.info(f"Showing student dashboard for: {user['name']}")
        self.user = user
        
        # Create main frame
        self.frame = ttk.Frame(self.root)
        self.frame.pack(fill="both", expand=True)
        
        # Create a background with gradient
        theme = self.app.theme_manager.current_theme
        bg_gradient = self.app.theme_manager.create_gradient_canvas(
            self.frame, 
            self.root.winfo_width(), 
            self.root.winfo_height(),
            theme["bg"], 
            theme["accent"],
            "vertical"
        )
        bg_gradient.place(x=0, y=0, relwidth=1, relheight=1)
        
        # Create header
        header_frame = GlassFrame(self.frame, opacity=0.1)
        header_frame.place(x=0, y=0, relwidth=1, height=120)
        
        # App logo/name
        logo_frame = ttk.Frame(header_frame)
        logo_frame.pack(side=tk.LEFT, padx=20)
        
        app_name = ttk.Label(
            logo_frame,
            text="SECURE MCQ",
            font=("Roboto", 18, "bold"),
            foreground=theme["heading_fg"]
        )
        app_name.pack(anchor="w")
        
        app_subtitle = ttk.Label(
            logo_frame,
            text="Student Portal",
            style="Subtext.TLabel"
        )
        app_subtitle.pack(anchor="w")
        
        # User info
        user_frame = ttk.Frame(header_frame)
        user_frame.pack(side=tk.RIGHT, padx=20)
        
        user_greeting = AnimatedLabel(
            user_frame,
            text=f"Welcome, {self.user['name']}",
            font=("Roboto", 14, "bold"),
            foreground=theme["heading_fg"]
        )
        user_greeting.pack(anchor="e")
        user_greeting.start_typing_animation(delay=30)
        
        user_details = ttk.Label(
            user_frame,
            text=f"USN: {self.user['usn']} | Section: {self.user['section'] or 'N/A'}",
            style="Subtext.TLabel"
        )
        user_details.pack(anchor="e")
        
        # Logout button
        logout_btn = ttk.Button(
            user_frame,
            text="Logout",
            command=self.app.logout
        )
        logout_btn.pack(anchor="e", pady=5)
        
        # Main content container
        content_frame = ttk.Frame(self.frame)
        content_frame.place(relx=0.5, rely=0.5, anchor="center", relwidth=0.9, relheight=0.65)
        
        # Left panel - Actions
        left_panel = GlassFrame(content_frame, opacity=0.2)
        left_panel.pack(side=tk.LEFT, fill="y", expand=False, padx=(0, 10), ipadx=20)
        
        action_label = ttk.Label(
            left_panel,
            text="ACTIONS",
            font=("Roboto", 16, "bold"),
            foreground=theme["accent"]
        )
        action_label.pack(pady=(20, 10), padx=20)
        
        ttk.Separator(left_panel, orient="horizontal").pack(fill="x", padx=20, pady=10)
        
        # Action buttons
        actions = [
            ("Start Assessment", self.show_subjects, "Primary.TButton"),
            ("View Results", self.show_results, "TButton"),
            ("Profile", self.show_profile, "TButton"),
            ("Settings", self.show_settings, "TButton")
        ]
        
        for text, command, style in actions:
            btn = ttk.Button(
                left_panel,
                text=text,
                style=style,
                command=command
            )
            btn.pack(fill="x", padx=20, pady=10, ipady=8)
        
        # Right panel - Dynamic content
        self.right_panel = GlassFrame(content_frame, opacity=0.2)
        self.right_panel.pack(side=tk.LEFT, fill="both", expand=True)
        
        # Show welcome content by default
        self.show_welcome()
        
        # Status bar
        status_bar = ttk.Frame(self.frame)
        status_bar.place(relx=0, rely=1, anchor="sw", relwidth=1, height=30)
        
        current_time = time.strftime("%H:%M:%S")
        date_str = time.strftime("%d %b %Y")
        
        status_text = ttk.Label(
            status_bar,
            text=f"Last login: {current_time} | Date: {date_str}",
            style="Subtext.TLabel",
            font=("Roboto", 8)
        )
        status_text.pack(side=tk.LEFT, padx=10)
        
        version_text = ttk.Label(
            status_bar,
            text=f"Version {self.app.config.get('app', 'version')}",
            style="Subtext.TLabel",
            font=("Roboto", 8)
        )
        version_text.pack(side=tk.RIGHT, padx=10)
        
        # Apply fade-in effect
        create_fade_in_effect(content_frame)
    
    def clear_right_panel(self):
        """Clear the right panel content."""
        for widget in self.right_panel.winfo_children():
            widget.destroy()
    
    def show_welcome(self):
        """Show welcome content on the right panel."""
        self.clear_right_panel()
        
        welcome_frame = ttk.Frame(self.right_panel)
        welcome_frame.pack(fill="both", expand=True, padx=30, pady=30)
        
        welcome_heading = ttk.Label(
            welcome_frame,
            text="Welcome to Secure MCQ 2025",
            style="Heading.TLabel"
        )
        welcome_heading.pack(pady=(0, 20))
        
        info_text = """
        Secure MCQ 2025 is an advanced assessment platform designed to provide a 
        secure and efficient testing environment. With this application, you can:
        
        • Take assessments in various subjects
        • View your past results and performance
        • Track your progress over time
        • Experience a secure exam environment
        
        To get started, click on "Start Assessment" on the left panel.
        """
        
        info_label = ttk.Label(
            welcome_frame,
            text=info_text,
            justify="left",
            wraplength=500
        )
        info_label.pack(pady=10, anchor="w")
        
        # Create fade-in effect
        create_fade_in_effect(welcome_frame)
    
    def show_subjects(self):
        """Show available subjects for assessment."""
        self.clear_right_panel()
        
        subjects_frame = ttk.Frame(self.right_panel)
        subjects_frame.pack(fill="both", expand=True, padx=30, pady=30)
        
        subjects_heading = ttk.Label(
            subjects_frame,
            text="Available Subjects",
            style="Heading.TLabel"
        )
        subjects_heading.pack(pady=(0, 20))
        
        # Get available subjects
        subjects = self.app.db.get_subjects()
        
        if not subjects:
            no_subjects = ttk.Label(
                subjects_frame,
                text="No subjects available. Please contact your administrator.",
                style="Subtext.TLabel"
            )
            no_subjects.pack(pady=20)
            return
        
        # Create subject cards
        subjects_container = ttk.Frame(subjects_frame)
        subjects_container.pack(fill="both", expand=True)
        
        # Create grid of subject cards
        row, col = 0, 0
        max_cols = 3
        
        for subject in subjects:
            # Create subject card
            card = GlassFrame(subjects_container, opacity=0.1)
            card.grid(row=row, column=col, padx=10, pady=10, sticky="nsew")
            
            # Subject name
            subject_name = ttk.Label(
                card,
                text=subject.capitalize(),
                font=("Roboto", 14, "bold")
            )
            subject_name.pack(pady=(15, 10))
            
            # Start button
            start_btn = ttk.Button(
                card,
                text="Start Assessment",
                style="Primary.TButton",
                command=lambda s=subject: self.confirm_start_exam(s)
            )
            start_btn.pack(pady=(10, 15))
            
            # Update grid position
            col += 1
            if col >= max_cols:
                col = 0
                row += 1
        
        # Configure grid weights
        for i in range(max_cols):
            subjects_container.columnconfigure(i, weight=1)
        
        # Create fade-in effect
        create_fade_in_effect(subjects_frame)
    
    def confirm_start_exam(self, subject):
        """Confirm exam start and check requirements."""
        # Check if there are questions for this subject
        questions = self.app.db.get_questions_by_subject(subject)
        
        if not questions or len(questions) == 0:
            messagebox.showerror(
                "No Questions Available", 
                f"There are no questions available for {subject.capitalize()}. Please contact your administrator."
            )
            return
        
        # Confirm exam start
        confirm = messagebox.askyesno(
            "Start Assessment",
            f"Are you ready to start the {subject.capitalize()} assessment?\n\n"
            "The exam will be conducted in a secure environment. "
            "Once started, you cannot exit until completion."
        )
        
        if confirm:
            self.app.show_exam(subject)
    
    def show_results(self):
        """Show student results."""
        self.clear_right_panel()
        
        results_frame = ttk.Frame(self.right_panel)
        results_frame.pack(fill="both", expand=True, padx=30, pady=30)
        
        results_heading = ttk.Label(
            results_frame,
            text="Your Assessment Results",
            style="Heading.TLabel"
        )
        results_heading.pack(pady=(0, 20))
        
        # Get student results
        results = self.app.db.get_results_by_user(self.user['usn'])
        
        if not results:
            no_results = ttk.Label(
                results_frame,
                text="You haven't taken any assessments yet.",
                style="Subtext.TLabel"
            )
            no_results.pack(pady=20)
            return
        
        # Create results table
        table_frame = ttk.Frame(results_frame)
        table_frame.pack(fill="both", expand=True)
        
        # Create treeview
        columns = ("subject", "score", "percentage", "date")
        tree = ttk.Treeview(
            table_frame,
            columns=columns,
            show="headings",
            height=10
        )
        
        # Define column headings
        tree.heading("subject", text="Subject")
        tree.heading("score", text="Score")
        tree.heading("percentage", text="Percentage")
        tree.heading("date", text="Date")
        
        # Define column widths
        tree.column("subject", width=150)
        tree.column("score", width=100)
        tree.column("percentage", width=100)
        tree.column("date", width=150)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill="y")
        tree.pack(side=tk.LEFT, fill="both", expand=True)
        
        # Add data to the table
        for result in results:
            result_id = result[0]
            subject = result[1].capitalize()
            score = result[2]
            total = result[3]
            percentage = f"{(score/total)*100:.2f}%"
            date = result[5]
            
            tree.insert(
                "",
                "end",
                values=(subject, f"{score}/{total}", percentage, date),
                tags=(result_id,)
            )
        
        # Create fade-in effect
        create_fade_in_effect(results_frame)
    
    def show_profile(self):
        """Show student profile."""
        self.clear_right_panel()
        
        profile_frame = ttk.Frame(self.right_panel)
        profile_frame.pack(fill="both", expand=True, padx=30, pady=30)
        
        profile_heading = ttk.Label(
            profile_frame,
            text="Student Profile",
            style="Heading.TLabel"
        )
        profile_heading.pack(pady=(0, 20))
        
        # Profile information
        info_frame = GlassFrame(profile_frame, opacity=0.1)
        info_frame.pack(fill="x", expand=False, pady=10, ipady=10)
        
        fields = [
            ("Name", self.user['name']),
            ("USN", self.user['usn']),
            ("Section", self.user['section'] or "Not assigned"),
            ("Role", "Student")
        ]
        
        for label, value in fields:
            field_frame = ttk.Frame(info_frame)
            field_frame.pack(fill="x", padx=20, pady=5)
            
            ttk.Label(
                field_frame,
                text=f"{label}:",
                width=15,
                font=("Roboto", 11, "bold")
            ).pack(side=tk.LEFT)
            
            ttk.Label(
                field_frame,
                text=value,
                font=("Roboto", 11)
            ).pack(side=tk.LEFT, padx=10)
        
        # Create fade-in effect
        create_fade_in_effect(profile_frame)
    
    def show_settings(self):
        """Show settings panel."""
        self.clear_right_panel()
        
        settings_frame = ttk.Frame(self.right_panel)
        settings_frame.pack(fill="both", expand=True, padx=30, pady=30)
        
        settings_heading = ttk.Label(
            settings_frame,
            text="Application Settings",
            style="Heading.TLabel"
        )
        settings_heading.pack(pady=(0, 20))
        
        # Settings options
        options_frame = GlassFrame(settings_frame, opacity=0.1)
        options_frame.pack(fill="x", expand=False, pady=10, ipady=10)
        
        # Theme setting
        theme_frame = ttk.Frame(options_frame)
        theme_frame.pack(fill="x", padx=20, pady=10)
        
        ttk.Label(
            theme_frame,
            text="Theme:",
            width=15,
            font=("Roboto", 11, "bold")
        ).pack(side=tk.LEFT)
        
        theme_var = tk.StringVar(value=self.app.theme_manager.theme_name)
        
        theme_combo = ttk.Combobox(
            theme_frame,
            textvariable=theme_var,
            values=["dark", "light"],
            state="readonly",
            width=20
        )
        theme_combo.pack(side=tk.LEFT, padx=10)
        
        def change_theme(event):
            self.app.theme_manager.switch_theme(theme_var.get())
            # Refresh the dashboard
            self.app.show_student_dashboard()
        
        theme_combo.bind("<<ComboboxSelected>>", change_theme)
        
        # Create fade-in effect
        create_fade_in_effect(settings_frame)