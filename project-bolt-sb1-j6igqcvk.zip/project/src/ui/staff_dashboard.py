import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from src.utils.logger import get_logger
from src.ui.components.glass_frame import GlassFrame
from src.ui.components.animated import AnimatedLabel, create_fade_in_effect
import time

class StaffDashboard:
    """Dashboard for staff users."""
    
    def __init__(self, root, app):
        self.logger = get_logger(__name__)
        self.root = root
        self.app = app
        self.frame = None
        self.user = None
    
    def show(self, user):
        """Display the staff dashboard."""
        self.logger.info(f"Showing staff dashboard for: {user['name']}")
        self.user = user
        
        # Create main frame
        self.frame = ttk.Frame(self.root)
        self.frame.pack(fill="both", expand=True)
        
        # Create a background with gradient
        theme = self.app.theme_manager.current_theme
        bg_gradient = self.app.theme_manager.create_gradient_canvas(
            self.frame, 
            self.root.winfo_width(), 
            self.root.winfo_height(),
            theme["bg"], 
            theme["accent"],
            "vertical"
        )
        bg_gradient.place(x=0, y=0, relwidth=1, relheight=1)
        
        # Create header
        header_frame = GlassFrame(self.frame, opacity=0.1)
        header_frame.place(x=0, y=0, relwidth=1, height=120)
        
        # App logo/name
        logo_frame = ttk.Frame(header_frame)
        logo_frame.pack(side=tk.LEFT, padx=20)
        
        app_name = ttk.Label(
            logo_frame,
            text="SECURE MCQ",
            font=("Roboto", 18, "bold"),
            foreground=theme["heading_fg"]
        )
        app_name.pack(anchor="w")
        
        app_subtitle = ttk.Label(
            logo_frame,
            text="Staff Console",
            style="Subtext.TLabel"
        )
        app_subtitle.pack(anchor="w")
        
        # User info
        user_frame = ttk.Frame(header_frame)
        user_frame.pack(side=tk.RIGHT, padx=20)
        
        user_greeting = AnimatedLabel(
            user_frame,
            text=f"Welcome, {self.user['name']}",
            font=("Roboto", 14, "bold"),
            foreground=theme["heading_fg"]
        )
        user_greeting.pack(anchor="e")
        user_greeting.start_typing_animation(delay=30)
        
        user_details = ttk.Label(
            user_frame,
            text=f"Staff ID: {self.user['usn']}",
            style="Subtext.TLabel"
        )
        user_details.pack(anchor="e")
        
        # Logout button
        logout_btn = ttk.Button(
            user_frame,
            text="Logout",
            command=self.app.logout
        )
        logout_btn.pack(anchor="e", pady=5)
        
        # Main content container
        content_frame = ttk.Frame(self.frame)
        content_frame.place(relx=0.5, rely=0.5, anchor="center", relwidth=0.9, relheight=0.65)
        
        # Left panel - Actions
        left_panel = GlassFrame(content_frame, opacity=0.2)
        left_panel.pack(side=tk.LEFT, fill="y", expand=False, padx=(0, 10), ipadx=20)
        
        action_label = ttk.Label(
            left_panel,
            text="ACTIONS",
            font=("Roboto", 16, "bold"),
            foreground=theme["accent"]
        )
        action_label.pack(pady=(20, 10), padx=20)
        
        ttk.Separator(left_panel, orient="horizontal").pack(fill="x", padx=20, pady=10)
        
        # Action buttons
        actions = [
            ("Question Management", self.show_question_management, "Primary.TButton"),
            ("Student Management", self.show_student_management, "TButton"),
            ("View Results", self.show_all_results, "TButton"),
            ("Settings", self.show_settings, "TButton")
        ]
        
        for text, command, style in actions:
            btn = ttk.Button(
                left_panel,
                text=text,
                style=style,
                command=command
            )
            btn.pack(fill="x", padx=20, pady=10, ipady=8)
        
        # Right panel - Dynamic content
        self.right_panel = GlassFrame(content_frame, opacity=0.2)
        self.right_panel.pack(side=tk.LEFT, fill="both", expand=True)
        
        # Show welcome content by default
        self.show_welcome()
        
        # Status bar
        status_bar = ttk.Frame(self.frame)
        status_bar.place(relx=0, rely=1, anchor="sw", relwidth=1, height=30)
        
        current_time = time.strftime("%H:%M:%S")
        date_str = time.strftime("%d %b %Y")
        
        status_text = ttk.Label(
            status_bar,
            text=f"Last login: {current_time} | Date: {date_str}",
            style="Subtext.TLabel",
            font=("Roboto", 8)
        )
        status_text.pack(side=tk.LEFT, padx=10)
        
        version_text = ttk.Label(
            status_bar,
            text=f"Version {self.app.config.get('app', 'version')}",
            style="Subtext.TLabel",
            font=("Roboto", 8)
        )
        version_text.pack(side=tk.RIGHT, padx=10)
        
        # Apply fade-in effect
        create_fade_in_effect(content_frame)
    
    def clear_right_panel(self):
        """Clear the right panel content."""
        for widget in self.right_panel.winfo_children():
            widget.destroy()
    
    def show_welcome(self):
        """Show welcome content on the right panel."""
        self.clear_right_panel()
        
        welcome_frame = ttk.Frame(self.right_panel)
        welcome_frame.pack(fill="both", expand=True, padx=30, pady=30)
        
        welcome_heading = ttk.Label(
            welcome_frame,
            text="Staff Console",
            style="Heading.TLabel"
        )
        welcome_heading.pack(pady=(0, 20))
        
        info_text = """
        Welcome to the Secure MCQ 2025 Staff Console. As a staff member, you have
        access to the following features:
        
        • Question Management: Add, edit, and import questions
        • Student Management: Add, edit, and import students
        • View Results: See student performance and analytics
        • Settings: Configure application settings
        
        Select an option from the left panel to get started.
        """
        
        info_label = ttk.Label(
            welcome_frame,
            text=info_text,
            justify="left",
            wraplength=500
        )
        info_label.pack(pady=10, anchor="w")
        
        # Create fade-in effect
        create_fade_in_effect(welcome_frame)
    
    def show_question_management(self):
        """Show question management interface."""
        self.clear_right_panel()
        
        questions_frame = ttk.Frame(self.right_panel)
        questions_frame.pack(fill="both", expand=True, padx=30, pady=30)
        
        questions_heading = ttk.Label(
            questions_frame,
            text="Question Bank Management",
            style="Heading.TLabel"
        )
        questions_heading.pack(pady=(0, 20))
        
        # Tabs for different question management functions
        tab_control = ttk.Notebook(questions_frame)
        tab_control.pack(fill="both", expand=True)
        
        # Add Question Tab
        add_tab = ttk.Frame(tab_control)
        tab_control.add(add_tab, text="Add Question")
        
        # Import Questions Tab
        import_tab = ttk.Frame(tab_control)
        tab_control.add(import_tab, text="Import Questions")
        
        # View Questions Tab
        view_tab = ttk.Frame(tab_control)
        tab_control.add(view_tab, text="View Questions")
        
        # Configure Add Question Tab
        self.setup_add_question_tab(add_tab)
        
        # Configure Import Questions Tab
        self.setup_import_questions_tab(import_tab)
        
        # Configure View Questions Tab
        self.setup_view_questions_tab(view_tab)
        
        # Create fade-in effect
        create_fade_in_effect(questions_frame)
    
    def setup_add_question_tab(self, parent):
        """Set up the Add Question tab."""
        form_frame = ttk.Frame(parent)
        form_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Form fields
        ttk.Label(form_frame, text="Subject:").grid(row=0, column=0, sticky="w", pady=10)
        self.subject_entry = ttk.Entry(form_frame, width=40)
        self.subject_entry.grid(row=0, column=1, sticky="ew", pady=10)
        
        ttk.Label(form_frame, text="Question:").grid(row=1, column=0, sticky="w", pady=10)
        self.question_entry = ttk.Entry(form_frame, width=40)
        self.question_entry.grid(row=1, column=1, sticky="ew", pady=10)
        
        # Options
        self.option_entries = []
        option_labels = ["Option A:", "Option B:", "Option C:", "Option D:"]
        
        for i, label in enumerate(option_labels):
            ttk.Label(form_frame, text=label).grid(row=2+i, column=0, sticky="w", pady=10)
            option_entry = ttk.Entry(form_frame, width=40)
            option_entry.grid(row=2+i, column=1, sticky="ew", pady=10)
            self.option_entries.append(option_entry)
        
        # Correct answer
        ttk.Label(form_frame, text="Correct Answer:").grid(row=6, column=0, sticky="w", pady=10)
        self.correct_var = tk.StringVar()
        correct_combo = ttk.Combobox(
            form_frame,
            textvariable=self.correct_var,
            values=["A", "B", "C", "D"],
            state="readonly",
            width=5
        )
        correct_combo.grid(row=6, column=1, sticky="w", pady=10)
        
        # Image path
        ttk.Label(form_frame, text="Image Path:").grid(row=7, column=0, sticky="w", pady=10)
        self.image_path_var = tk.StringVar()
        image_frame = ttk.Frame(form_frame)
        image_frame.grid(row=7, column=1, sticky="ew", pady=10)
        
        image_entry = ttk.Entry(image_frame, textvariable=self.image_path_var, width=30)
        image_entry.pack(side=tk.LEFT, fill="x", expand=True)
        
        browse_btn = ttk.Button(
            image_frame,
            text="Browse",
            command=self.browse_image
        )
        browse_btn.pack(side=tk.RIGHT, padx=(5, 0))
        
        # Save button
        save_btn = ttk.Button(
            form_frame,
            text="Save Question",
            style="Primary.TButton",
            command=self.save_question
        )
        save_btn.grid(row=8, column=0, columnspan=2, pady=20)
        
        # Configure grid
        form_frame.columnconfigure(1, weight=1)
    
    def setup_import_questions_tab(self, parent):
        """Set up the Import Questions tab."""
        import_frame = ttk.Frame(parent)
        import_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Instructions
        instructions = """
        Import questions from an Excel file. The Excel file should have the following columns:
        
        • Subject: The subject of the question
        • Question: The question text
        • Option A: The first option
        • Option B: The second option
        • Option C: The third option
        • Option D: The fourth option
        • Correct: The correct answer (A, B, C, or D)
        • Image Path (optional): Path to an image file
        
        Click 'Select File' to choose an Excel file to import.
        """
        
        instructions_label = ttk.Label(
            import_frame,
            text=instructions,
            wraplength=500,
            justify="left"
        )
        instructions_label.pack(fill="x", pady=20, anchor="w")
        
        # File selection
        file_frame = ttk.Frame(import_frame)
        file_frame.pack(fill="x", pady=10)
        
        self.import_file_var = tk.StringVar()
        
        ttk.Label(file_frame, text="Excel File:").pack(side=tk.LEFT, padx=(0, 10))
        
        file_entry = ttk.Entry(file_frame, textvariable=self.import_file_var, width=40)
        file_entry.pack(side=tk.LEFT, fill="x", expand=True)
        
        browse_btn = ttk.Button(
            file_frame,
            text="Select File",
            command=self.browse_excel_file
        )
        browse_btn.pack(side=tk.LEFT, padx=10)
        
        # Import button
        import_btn = ttk.Button(
            import_frame,
            text="Import Questions",
            style="Primary.TButton",
            command=self.import_questions
        )
        import_btn.pack(pady=20)
        
        # Template download
        template_btn = ttk.Button(
            import_frame,
            text="Download Template",
            command=self.download_question_template
        )
        template_btn.pack(pady=10)
    
    def setup_view_questions_tab(self, parent):
        """Set up the View Questions tab."""
        view_frame = ttk.Frame(parent)
        view_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Filter options
        filter_frame = ttk.Frame(view_frame)
        filter_frame.pack(fill="x", pady=10)
        
        ttk.Label(filter_frame, text="Subject:").pack(side=tk.LEFT, padx=(0, 10))
        
        # Get available subjects
        subjects = self.app.db.get_subjects()
        subjects.insert(0, "All Subjects")
        
        self.filter_subject = tk.StringVar(value="All Subjects")
        subject_combo = ttk.Combobox(
            filter_frame,
            textvariable=self.filter_subject,
            values=subjects,
            state="readonly",
            width=20
        )
        subject_combo.pack(side=tk.LEFT)
        
        filter_btn = ttk.Button(
            filter_frame,
            text="Apply Filter",
            command=self.load_questions
        )
        filter_btn.pack(side=tk.LEFT, padx=10)
        
        # Questions table
        table_frame = ttk.Frame(view_frame)
        table_frame.pack(fill="both", expand=True, pady=10)
        
        # Create treeview
        columns = ("id", "subject", "question", "correct")
        self.questions_tree = ttk.Treeview(
            table_frame,
            columns=columns,
            show="headings",
            height=10
        )
        
        # Define column headings
        self.questions_tree.heading("id", text="ID")
        self.questions_tree.heading("subject", text="Subject")
        self.questions_tree.heading("question", text="Question")
        self.questions_tree.heading("correct", text="Correct")
        
        # Define column widths
        self.questions_tree.column("id", width=50)
        self.questions_tree.column("subject", width=100)
        self.questions_tree.column("question", width=400)
        self.questions_tree.column("correct", width=70)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=self.questions_tree.yview)
        self.questions_tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill="y")
        self.questions_tree.pack(side=tk.LEFT, fill="both", expand=True)
        
        # Load initial questions
        self.load_questions()
    
    def load_questions(self):
        """Load questions based on filter."""
        # Clear existing items
        for item in self.questions_tree.get_children():
            self.questions_tree.delete(item)
        
        try:
            subject_filter = self.filter_subject.get()
            
            if subject_filter == "All Subjects":
                # Get all subjects
                subjects = self.app.db.get_subjects()
                questions = []
                
                for subject in subjects:
                    subject_questions = self.app.db.get_questions_by_subject(subject)
                    questions.extend(subject_questions)
            else:
                # Get questions for specific subject
                questions = self.app.db.get_questions_by_subject(subject_filter)
            
            # Add questions to treeview
            for question in questions:
                self.questions_tree.insert(
                    "",
                    "end",
                    values=(
                        question[0],
                        question[1].capitalize(),
                        question[2][:50] + "..." if len(question[2]) > 50 else question[2],
                        question[7]
                    )
                )
            
            if not questions:
                self.questions_tree.insert("", "end", values=("", "No questions found", "", ""))
        except Exception as e:
            self.logger.error(f"Error loading questions: {str(e)}")
            messagebox.showerror("Error", f"Failed to load questions: {str(e)}")
    
    def browse_image(self):
        """Browse for an image file."""
        file_path = filedialog.askopenfilename(
            filetypes=[
                ("Image Files", "*.png *.jpg *.jpeg *.gif *.bmp")
            ]
        )
        
        if file_path:
            self.image_path_var.set(file_path)
    
    def browse_excel_file(self):
        """Browse for an Excel file."""
        file_path = filedialog.askopenfilename(
            filetypes=[
                ("Excel Files", "*.xlsx *.xls")
            ]
        )
        
        if file_path:
            self.import_file_var.set(file_path)
    
    def save_question(self):
        """Save a question to the database."""
        try:
            subject = self.subject_entry.get()
            question = self.question_entry.get()
            options = [entry.get() for entry in self.option_entries]
            correct = self.correct_var.get()
            image_path = self.image_path_var.get()
            
            # Validate input
            if not subject or not question or not all(options) or not correct:
                messagebox.showwarning("Input Error", "All fields except image path are required")
                return
            
            # Save question
            success = self.app.db.add_question(
                subject=subject,
                question=question,
                options=options,
                correct=correct,
                image_path=image_path if image_path else None,
                created_by=self.user['id']
            )
            
            if success:
                messagebox.showinfo("Success", "Question saved successfully")
                
                # Clear form
                self.subject_entry.delete(0, tk.END)
                self.question_entry.delete(0, tk.END)
                for entry in self.option_entries:
                    entry.delete(0, tk.END)
                self.correct_var.set("")
                self.image_path_var.set("")
            else:
                messagebox.showerror("Error", "Failed to save question")
        except Exception as e:
            self.logger.error(f"Error saving question: {str(e)}")
            messagebox.showerror("Error", f"Failed to save question: {str(e)}")
    
    def import_questions(self):
        """Import questions from Excel."""
        file_path = self.import_file_var.get()
        
        if not file_path:
            messagebox.showwarning("Input Error", "Please select an Excel file")
            return
        
        try:
            success, message = self.app.db.import_questions_from_excel(
                file_path=file_path,
                created_by=self.user['id']
            )
            
            if success:
                messagebox.showinfo("Import Successful", message)
                self.import_file_var.set("")
            else:
                messagebox.showerror("Import Error", message)
        except Exception as e:
            self.logger.error(f"Error importing questions: {str(e)}")
            messagebox.showerror("Error", f"Failed to import questions: {str(e)}")
    
    def download_question_template(self):
        """Download question template Excel file."""
        try:
            import pandas as pd
            
            # Define template columns
            columns = ["Subject", "Question", "Option A", "Option B", "Option C", "Option D", "Correct", "Image Path"]
            
            # Create empty DataFrame
            df = pd.DataFrame(columns=columns)
            
            # Add sample row
            df.loc[0] = [
                "Mathematics",
                "What is 2 + 2?",
                "3",
                "4",
                "5",
                "6",
                "B",
                ""
            ]
            
            # Save file
            save_path = filedialog.asksaveasfilename(
                defaultextension=".xlsx",
                filetypes=[("Excel Files", "*.xlsx")],
                initialfile="question_template.xlsx"
            )
            
            if save_path:
                df.to_excel(save_path, index=False)
                messagebox.showinfo("Success", f"Template saved to {save_path}")
        except Exception as e:
            self.logger.error(f"Error creating template: {str(e)}")
            messagebox.showerror("Error", f"Failed to create template: {str(e)}")
    
    def show_student_management(self):
        """Show student management interface."""
        self.clear_right_panel()
        
        students_frame = ttk.Frame(self.right_panel)
        students_frame.pack(fill="both", expand=True, padx=30, pady=30)
        
        students_heading = ttk.Label(
            students_frame,
            text="Student Management",
            style="Heading.TLabel"
        )
        students_heading.pack(pady=(0, 20))
        
        # Tabs for different student management functions
        tab_control = ttk.Notebook(students_frame)
        tab_control.pack(fill="both", expand=True)
        
        # Add Student Tab
        add_tab = ttk.Frame(tab_control)
        tab_control.add(add_tab, text="Add Student")
        
        # Import Students Tab
        import_tab = ttk.Frame(tab_control)
        tab_control.add(import_tab, text="Import Students")
        
        # View Students Tab
        view_tab = ttk.Frame(tab_control)
        tab_control.add(view_tab, text="View Students")
        
        # Configure Add Student Tab
        self.setup_add_student_tab(add_tab)
        
        # Configure Import Students Tab
        self.setup_import_students_tab(import_tab)
        
        # Configure View Students Tab
        self.setup_view_students_tab(view_tab)
        
        # Create fade-in effect
        create_fade_in_effect(students_frame)
    
    def setup_add_student_tab(self, parent):
        """Set up the Add Student tab."""
        form_frame = ttk.Frame(parent)
        form_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Form fields
        ttk.Label(form_frame, text="Name:").grid(row=0, column=0, sticky="w", pady=10)
        self.student_name_entry = ttk.Entry(form_frame, width=40)
        self.student_name_entry.grid(row=0, column=1, sticky="ew", pady=10)
        
        ttk.Label(form_frame, text="USN:").grid(row=1, column=0, sticky="w", pady=10)
        self.student_usn_entry = ttk.Entry(form_frame, width=40)
        self.student_usn_entry.grid(row=1, column=1, sticky="ew", pady=10)
        
        ttk.Label(form_frame, text="Section:").grid(row=2, column=0, sticky="w", pady=10)
        self.student_section_entry = ttk.Entry(form_frame, width=40)
        self.student_section_entry.grid(row=2, column=1, sticky="ew", pady=10)
        
        ttk.Label(form_frame, text="Password:").grid(row=3, column=0, sticky="w", pady=10)
        self.student_password_entry = ttk.Entry(form_frame, width=40, show="•")
        self.student_password_entry.grid(row=3, column=1, sticky="ew", pady=10)
        
        # Save button
        save_btn = ttk.Button(
            form_frame,
            text="Add Student",
            style="Primary.TButton",
            command=self.save_student
        )
        save_btn.grid(row=4, column=0, columnspan=2, pady=20)
        
        # Configure grid
        form_frame.columnconfigure(1, weight=1)
    
    def setup_import_students_tab(self, parent):
        """Set up the Import Students tab."""
        import_frame = ttk.Frame(parent)
        import_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Instructions
        instructions = """
        Import students from an Excel file. The Excel file should have the following columns:
        
        • Name: The student's full name
        • USN: The student's USN/ID
        • Section: The student's section
        • Password: The student's password
        
        Click 'Select File' to choose an Excel file to import.
        """
        
        instructions_label = ttk.Label(
            import_frame,
            text=instructions,
            wraplength=500,
            justify="left"
        )
        instructions_label.pack(fill="x", pady=20, anchor="w")
        
        # File selection
        file_frame = ttk.Frame(import_frame)
        file_frame.pack(fill="x", pady=10)
        
        self.student_import_file_var = tk.StringVar()
        
        ttk.Label(file_frame, text="Excel File:").pack(side=tk.LEFT, padx=(0, 10))
        
        file_entry = ttk.Entry(file_frame, textvariable=self.student_import_file_var, width=40)
        file_entry.pack(side=tk.LEFT, fill="x", expand=True)
        
        browse_btn = ttk.Button(
            file_frame,
            text="Select File",
            command=self.browse_student_excel_file
        )
        browse_btn.pack(side=tk.LEFT, padx=10)
        
        # Import button
        import_btn = ttk.Button(
            import_frame,
            text="Import Students",
            style="Primary.TButton",
            command=self.import_students
        )
        import_btn.pack(pady=20)
        
        # Template download
        template_btn = ttk.Button(
            import_frame,
            text="Download Template",
            command=self.download_student_template
        )
        template_btn.pack(pady=10)
    
    def setup_view_students_tab(self, parent):
        """Set up the View Students tab."""
        # This is a placeholder for future implementation
        view_frame = ttk.Frame(parent)
        view_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Students table
        table_frame = ttk.Frame(view_frame)
        table_frame.pack(fill="both", expand=True, pady=10)
        
        # Create treeview
        columns = ("id", "name", "usn", "section")
        self.students_tree = ttk.Treeview(
            table_frame,
            columns=columns,
            show="headings",
            height=10
        )
        
        # Define column headings
        self.students_tree.heading("id", text="ID")
        self.students_tree.heading("name", text="Name")
        self.students_tree.heading("usn", text="USN")
        self.students_tree.heading("section", text="Section")
        
        # Define column widths
        self.students_tree.column("id", width=50)
        self.students_tree.column("name", width=200)
        self.students_tree.column("usn", width=150)
        self.students_tree.column("section", width=100)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=self.students_tree.yview)
        self.students_tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill="y")
        self.students_tree.pack(side=tk.LEFT, fill="both", expand=True)
        
        # Load students
        self.load_students()
    
    def load_students(self):
        """Load students for the view tab."""
        # This is a placeholder for future implementation
        # In a real application, you would fetch students from the database
        # For now, just display a message
        self.students_tree.insert("", "end", values=("", "Student data loading...", "", ""))
    
    def browse_student_excel_file(self):
        """Browse for an Excel file."""
        file_path = filedialog.askopenfilename(
            filetypes=[
                ("Excel Files", "*.xlsx *.xls")
            ]
        )
        
        if file_path:
            self.student_import_file_var.set(file_path)
    
    def save_student(self):
        """Save a student to the database."""
        try:
            name = self.student_name_entry.get()
            usn = self.student_usn_entry.get()
            section = self.student_section_entry.get()
            password = self.student_password_entry.get()
            
            # Validate input
            if not name or not usn or not password:
                messagebox.showwarning("Input Error", "Name, USN, and password are required")
                return
            
            # Save student
            success = self.app.db.add_user(
                name=name,
                role='student',
                usn=usn,
                password=password,
                section=section
            )
            
            if success:
                messagebox.showinfo("Success", "Student added successfully")
                
                # Clear form
                self.student_name_entry.delete(0, tk.END)
                self.student_usn_entry.delete(0, tk.END)
                self.student_section_entry.delete(0, tk.END)
                self.student_password_entry.delete(0, tk.END)
            else:
                messagebox.showerror("Error", "Failed to add student. USN may already exist.")
        except Exception as e:
            self.logger.error(f"Error adding student: {str(e)}")
            messagebox.showerror("Error", f"Failed to add student: {str(e)}")
    
    def import_students(self):
        """Import students from Excel."""
        file_path = self.student_import_file_var.get()
        
        if not file_path:
            messagebox.showwarning("Input Error", "Please select an Excel file")
            return
        
        try:
            success, message = self.app.db.import_students_from_excel(file_path)
            
            if success:
                messagebox.showinfo("Import Successful", message)
                self.student_import_file_var.set("")
            else:
                messagebox.showerror("Import Error", message)
        except Exception as e:
            self.logger.error(f"Error importing students: {str(e)}")
            messagebox.showerror("Error", f"Failed to import students: {str(e)}")
    
    def download_student_template(self):
        """Download student template Excel file."""
        try:
            import pandas as pd
            
            # Define template columns
            columns = ["Name", "USN", "Section", "Password"]
            
            # Create empty DataFrame
            df = pd.DataFrame(columns=columns)
            
            # Add sample row
            df.loc[0] = [
                "John Doe",
                "USN123456",
                "A",
                "password123"
            ]
            
            # Save file
            save_path = filedialog.asksaveasfilename(
                defaultextension=".xlsx",
                filetypes=[("Excel Files", "*.xlsx")],
                initialfile="student_template.xlsx"
            )
            
            if save_path:
                df.to_excel(save_path, index=False)
                messagebox.showinfo("Success", f"Template saved to {save_path}")
        except Exception as e:
            self.logger.error(f"Error creating template: {str(e)}")
            messagebox.showerror("Error", f"Failed to create template: {str(e)}")
    
    def show_all_results(self):
        """Show all exam results."""
        self.clear_right_panel()
        
        results_frame = ttk.Frame(self.right_panel)
        results_frame.pack(fill="both", expand=True, padx=30, pady=30)
        
        results_heading = ttk.Label(
            results_frame,
            text="Exam Analytics",
            style="Heading.TLabel"
        )
        results_heading.pack(pady=(0, 20))
        
        # Get all results
        results = self.app.db.get_all_results()
        
        if not results:
            no_results = ttk.Label(
                results_frame,
                text="No results found.",
                style="Subtext.TLabel"
            )
            no_results.pack(pady=20)
            return
        
        # Create results table
        table_frame = ttk.Frame(results_frame)
        table_frame.pack(fill="both", expand=True)
        
        # Create treeview
        columns = ("name", "usn", "subject", "score", "date")
        tree = ttk.Treeview(
            table_frame,
            columns=columns,
            show="headings",
            height=10
        )
        
        # Define column headings
        tree.heading("name", text="Name")
        tree.heading("usn", text="USN")
        tree.heading("subject", text="Subject")
        tree.heading("score", text="Score")
        tree.heading("date", text="Date")
        
        # Define column widths
        tree.column("name", width=150)
        tree.column("usn", width=100)
        tree.column("subject", width=100)
        tree.column("score", width=100)
        tree.column("date", width=150)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill="y")
        tree.pack(side=tk.LEFT, fill="both", expand=True)
        
        # Add data to the table
        for result in results:
            result_id = result[0]
            name = result[1]
            usn = result[2]
            subject = result[3].capitalize()
            score = f"{result[4]}/{result[5]}"
            date = result[6]
            
            tree.insert(
                "",
                "end",
                values=(name, usn, subject, score, date),
                tags=(result_id,)
            )
        
        # Create fade-in effect
        create_fade_in_effect(results_frame)
    
    def show_settings(self):
        """Show settings panel."""
        self.clear_right_panel()
        
        settings_frame = ttk.Frame(self.right_panel)
        settings_frame.pack(fill="both", expand=True, padx=30, pady=30)
        
        settings_heading = ttk.Label(
            settings_frame,
            text="Application Settings",
            style="Heading.TLabel"
        )
        settings_heading.pack(pady=(0, 20))
        
        # Settings options
        options_frame = GlassFrame(settings_frame, opacity=0.1)
        options_frame.pack(fill="x", expand=False, pady=10, ipady=10)
        
        # Theme setting
        theme_frame = ttk.Frame(options_frame)
        theme_frame.pack(fill="x", padx=20, pady=10)
        
        ttk.Label(
            theme_frame,
            text="Theme:",
            width=15,
            font=("Roboto", 11, "bold")
        ).pack(side=tk.LEFT)
        
        theme_var = tk.StringVar(value=self.app.theme_manager.theme_name)
        
        theme_combo = ttk.Combobox(
            theme_frame,
            textvariable=theme_var,
            values=["dark", "light"],
            state="readonly",
            width=20
        )
        theme_combo.pack(side=tk.LEFT, padx=10)
        
        def change_theme(event):
            self.app.theme_manager.switch_theme(theme_var.get())
            # Refresh the dashboard
            self.app.show_staff_dashboard()
        
        theme_combo.bind("<<ComboboxSelected>>", change_theme)
        
        # Exam settings
        exam_frame = ttk.Frame(options_frame)
        exam_frame.pack(fill="x", padx=20, pady=10)
        
        ttk.Label(
            exam_frame,
            text="Time per Question:",
            width=15,
            font=("Roboto", 11, "bold")
        ).pack(side=tk.LEFT)
        
        time_var = tk.StringVar(value=str(self.app.config.get("exam", "time_limit")))
        
        time_entry = ttk.Entry(
            exam_frame,
            textvariable=time_var,
            width=5
        )
        time_entry.pack(side=tk.LEFT, padx=10)
        
        ttk.Label(
            exam_frame,
            text="seconds"
        ).pack(side=tk.LEFT)
        
        # Save settings button
        save_btn = ttk.Button(
            settings_frame,
            text="Save Settings",
            style="Primary.TButton",
            command=lambda: self.save_settings(time_var.get())
        )
        save_btn.pack(pady=20)
        
        # Create fade-in effect
        create_fade_in_effect(settings_frame)
    
    def save_settings(self, time_limit):
        """Save application settings."""
        try:
            time_limit = int(time_limit)
            if time_limit < 5:
                messagebox.showwarning("Invalid Value", "Time per question must be at least 5 seconds")
                return
            
            self.app.config.set("exam", "time_limit", time_limit)
            messagebox.showinfo("Success", "Settings saved successfully")
        except ValueError:
            messagebox.showwarning("Invalid Value", "Time per question must be a number")
        except Exception as e:
            self.logger.error(f"Error saving settings: {str(e)}")
            messagebox.showerror("Error", f"Failed to save settings: {str(e)}")