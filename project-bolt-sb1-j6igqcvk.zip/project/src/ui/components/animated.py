import tkinter as tk
from tkinter import ttk
import time

class AnimatedLabel(ttk.Label):
    """A label widget with animation capabilities."""
    
    def __init__(self, parent, **kwargs):
        super().__init__(parent, **kwargs)
        self.original_text = kwargs.get('text', '')
        self.after_id = None
    
    def start_typing_animation(self, delay=100, callback=None):
        """Start a typing animation effect."""
        self.config(text="")
        self._typing_animation(0, delay, callback)
    
    def _typing_animation(self, index, delay, callback):
        """Internal method for typing animation."""
        if index <= len(self.original_text):
            self.config(text=self.original_text[:index])
            self.after_id = self.after(delay, lambda: self._typing_animation(index + 1, delay, callback))
        elif callback:
            callback()
    
    def fade_in(self, duration=1000, steps=20, callback=None):
        """Start a fade-in animation effect."""
        self.place_forget()  # Hide initially
        self._fade_in_step(0, duration/steps, steps, callback)
    
    def _fade_in_step(self, step, delay, total_steps, callback):
        """Internal method for fade-in animation."""
        if step <= total_steps:
            alpha = step / total_steps
            # For ttk widgets, we can't easily adjust alpha directly
            # So we use other visual cues like foreground color adjustment
            # This is a simplified approach
            self.place(relx=0.5, rely=0.5, anchor="center")
            self.after_id = self.after(int(delay), lambda: self._fade_in_step(step + 1, delay, total_steps, callback))
        elif callback:
            callback()
    
    def stop_animation(self):
        """Stop any ongoing animation."""
        if self.after_id:
            self.after_cancel(self.after_id)
            self.after_id = None


def create_fade_in_effect(widget, duration=500):
    """Create a fade-in effect for any widget."""
    widget.update_idletasks()  # Make sure widget dimensions are calculated
    
    # Create a canvas overlay with the same dimensions
    parent = widget.winfo_toplevel()
    canvas = tk.Canvas(
        parent,
        width=widget.winfo_width(),
        height=widget.winfo_height(),
        highlightthickness=0,
        bg="black"
    )
    
    # Position the canvas exactly over the widget
    x, y = widget.winfo_rootx() - parent.winfo_rootx(), widget.winfo_rooty() - parent.winfo_rooty()
    canvas.place(x=x, y=y)
    
    # Fade out the overlay
    steps = 10
    for i in range(steps + 1):
        alpha = (steps - i) / steps
        # Calculate hex alpha value (from 00 to FF)
        hex_alpha = format(int(alpha * 255), '02x')
        canvas.configure(bg=f"#{hex_alpha}{hex_alpha}{hex_alpha}")
        canvas.update()
        time.sleep(duration / 1000 / steps)
    
    # Remove the canvas
    canvas.destroy()