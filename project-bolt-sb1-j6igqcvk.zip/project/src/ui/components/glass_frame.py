import tkinter as tk
from tkinter import ttk

class GlassFrame(ttk.Frame):
    """
    A frame with a glass morphism effect.
    This creates a semi-transparent frame with a subtle blur effect.
    """
    
    def __init__(self, parent, opacity=0.2, corner_radius=10, blur_intensity=0, **kwargs):
        """
        Initialize a glass frame.
        
        Args:
            parent: The parent widget
            opacity: Opacity level (0.0 to 1.0)
            corner_radius: Radius for rounded corners
            blur_intensity: Blur effect intensity (0 to 10)
            **kwargs: Additional arguments for ttk.Frame
        """
        super().__init__(parent, **kwargs)
        
        self.opacity = opacity
        self.corner_radius = corner_radius
        self.blur_intensity = blur_intensity
        
        # Create the glass effect
        self.bind("<Configure>", self._on_configure)
    
    def _on_configure(self, event):
        """Handle resize events to update the glass effect."""
        if not hasattr(self, 'canvas') or not self.canvas.winfo_exists():
            # Create a canvas for the glass effect
            self.canvas = tk.Canvas(
                self,
                highlightthickness=0,
                bg="",
                borderwidth=0
            )
            self.canvas.place(x=0, y=0, relwidth=1, relheight=1)
        
        # Get the widget's width and height
        width = self.winfo_width()
        height = self.winfo_height()
        
        # Delete any existing glass items
        self.canvas.delete("glass")
        
        # Create the glass rectangle with rounded corners
        self.canvas.create_rectangle(
            0, 0, width, height,
            fill=f"black",
            outline="",
            width=0,
            stipple="gray25",  # This creates a semi-transparent effect
            tags=("glass",)
        )
        
        # Add a subtle border for the glass effect
        self.canvas.create_rectangle(
            2, 2, width-2, height-2,
            outline="#ffffff",
            width=1,
            tags=("glass",)
        )
        
        # Apply styling based on the current theme
        style = ttk.Style()
        bg_color = style.lookup("TFrame", "background") or "#000000"
        
        # Convert background color to RGB
        r, g, b = self.winfo_rgb(bg_color)
        r, g, b = r//256, g//256, b//256
        
        # Apply opacity
        opacity_hex = format(int(self.opacity * 255), '02x')
        glass_color = f"#{r:02x}{g:02x}{b:02x}{opacity_hex}"
        
        # Update the glass rectangle color
        self.canvas.itemconfig("glass", fill=glass_color)
        
        # Lower the canvas to the bottom so it doesn't interfere with child widgets
        self.canvas.lower()