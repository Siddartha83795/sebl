import tkinter as tk
from tkinter import ttk, messagebox
import time
import random
from PIL import Image, ImageTk
from src.utils.logger import get_logger
from src.ui.components.glass_frame import GlassFrame
from src.ui.components.animated import create_fade_in_effect

class ExamScreen:
    """Exam screen for taking assessments."""
    
    def __init__(self, root, app):
        self.logger = get_logger(__name__)
        self.root = root
        self.app = app
        self.frame = None
        
        # Exam state
        self.user = None
        self.subject = ""
        self.questions = []
        self.current_question = 0
        self.score = 0
        self.start_time = 0
        self.timer_id = None
        self.time_left = 0
        self.time_per_question = 30  # Default, will be updated from config
        
        # User responses
        self.responses = []
        self.current_response = None
        self.selected_option = tk.StringVar()
    
    def start_exam(self, user, subject):
        """Start the exam."""
        self.logger.info(f"Starting exam for {user['name']}, subject: {subject}")
        self.user = user
        self.subject = subject
        
        # Get time limit from config
        self.time_per_question = self.app.config.get("exam", "time_limit")
        
        # Load questions
        self.questions = self.app.db.get_questions_by_subject(subject)
        
        if not self.questions or len(self.questions) == 0:
            messagebox.showerror("Error", "No questions available for this subject")
            self.app.show_student_dashboard()
            return
        
        # Enable secure mode
        secure_mode_enabled = self.app.security_manager.enable_secure_mode()
        
        if not secure_mode_enabled:
            # If secure mode couldn't be enabled, ask if user wants to continue anyway
            proceed = messagebox.askyesno(
                "Security Warning",
                "Could not enable all security features. Continue anyway?"
            )
            
            if not proceed:
                self.app.show_student_dashboard()
                return
        
        # Initialize exam state
        self.current_question = 0
        self.score = 0
        self.start_time = time.time()
        self.responses = []
        
        # Shuffle questions if enabled in config
        if self.app.config.get("exam", "shuffle_questions"):
            random.shuffle(self.questions)
        
        # Show first question
        self.show_question()
    
    def show_question(self):
        """Display the current question."""
        # Create main frame if it doesn't exist
        if not self.frame:
            self.frame = ttk.Frame(self.root)
            self.frame.pack(fill="both", expand=True)
        else:
            # Clear existing widgets
            for widget in self.frame.winfo_children():
                widget.destroy()
        
        # Create a background with gradient
        theme = self.app.theme_manager.current_theme
        bg_gradient = self.app.theme_manager.create_gradient_canvas(
            self.frame, 
            self.root.winfo_width(), 
            self.root.winfo_height(),
            theme["bg"], 
            "#000000",
            "vertical"
        )
        bg_gradient.place(x=0, y=0, relwidth=1, relheight=1)
        
        # Check if we've reached the end of the questions
        if self.current_question >= len(self.questions):
            self.end_exam()
            return
        
        # Get current question
        q = self.questions[self.current_question]
        
        # Initialize response tracking for this question
        self.current_response = {
            'question_id': q[0],
            'user_answer': None,
            'is_correct': False,
            'time_started': time.time(),
            'time_taken': 0
        }
        
        # Reset selected option
        self.selected_option.set("")
        
        # Header bar
        header_frame = GlassFrame(self.frame, opacity=0.1)
        header_frame.place(x=0, y=0, relwidth=1, height=60)
        
        # Subject and progress
        subject_label = ttk.Label(
            header_frame,
            text=f"Subject: {self.subject.capitalize()}",
            font=("Roboto", 12, "bold")
        )
        subject_label.pack(side=tk.LEFT, padx=20)
        
        progress_label = ttk.Label(
            header_frame,
            text=f"Question {self.current_question + 1} of {len(self.questions)}",
            font=("Roboto", 12)
        )
        progress_label.pack(side=tk.LEFT, padx=20)
        
        # Timer
        self.time_left = self.time_per_question
        self.timer_label = ttk.Label(
            header_frame,
            text=f"Time Left: {self.time_left}s",
            font=("Roboto", 12)
        )
        self.timer_label.pack(side=tk.RIGHT, padx=20)
        
        # Start timer
        self.update_timer()
        
        # Question container
        question_container = GlassFrame(self.frame, opacity=0.2)
        question_container.place(relx=0.5, rely=0.45, anchor="center", relwidth=0.8, relheight=0.65)
        
        # Question number and text
        question_header = ttk.Label(
            question_container,
            text=f"Question {self.current_question + 1}:",
            font=("Roboto", 14, "bold")
        )
        question_header.pack(pady=(20, 10), padx=30, anchor="w")
        
        question_text = ttk.Label(
            question_container,
            text=q[2],
            font=("Roboto", 12),
            wraplength=700,
            justify="left"
        )
        question_text.pack(pady=10, padx=30, anchor="w")
        
        # Display image if available
        if q[8] and q[8].strip():
            try:
                img = Image.open(q[8])
                img = img.resize((400, 300), Image.LANCZOS)
                photo = ImageTk.PhotoImage(img)
                
                img_frame = ttk.Frame(question_container)
                img_frame.pack(pady=15)
                
                img_label = ttk.Label(img_frame, image=photo)
                img_label.image = photo  # Keep a reference to prevent garbage collection
                img_label.pack()
            except Exception as e:
                self.logger.error(f"Error loading image: {str(e)}")
                error_label = ttk.Label(
                    question_container,
                    text="[Image could not be loaded]",
                    foreground=theme["error"]
                )
                error_label.pack(pady=5)
        
        # Options
        options_frame = ttk.Frame(question_container)
        options_frame.pack(fill="x", pady=20, padx=30)
        
        option_labels = ["A", "B", "C", "D"]
        option_values = [q[3], q[4], q[5], q[6]]
        
        for i, (label, value) in enumerate(zip(option_labels, option_values)):
            option_frame = ttk.Frame(options_frame)
            option_frame.pack(fill="x", pady=8)
            
            radio = ttk.Radiobutton(
                option_frame,
                text=f"{label}. {value}",
                variable=self.selected_option,
                value=label,
                command=self.on_option_selected
            )
            radio.pack(side=tk.LEFT, fill="x", expand=True)
        
        # Navigation
        nav_frame = ttk.Frame(self.frame)
        nav_frame.place(relx=0.5, rely=0.95, anchor="s", relwidth=0.8, height=50)
        
        # Next/Submit button
        btn_text = "Next" if self.current_question < len(self.questions) - 1 else "Submit"
        next_btn = ttk.Button(
            nav_frame,
            text=btn_text,
            style="Primary.TButton",
            command=self.next_question
        )
        next_btn.pack(side=tk.RIGHT, padx=10)
        
        # Apply fade-in effect
        create_fade_in_effect(question_container)
    
    def update_timer(self):
        """Update the timer display."""
        if self.time_left > 0:
            self.time_left -= 1
            self.timer_label.config(text=f"Time Left: {self.time_left}s")
            
            # Change color when time is running low
            if self.time_left <= 5:
                self.timer_label.config(foreground=self.app.theme_manager.current_theme["error"])
            
            self.timer_id = self.root.after(1000, self.update_timer)
        else:
            # Time's up for this question
            self.next_question()
    
    def on_option_selected(self):
        """Handle option selection."""
        self.current_response['user_answer'] = self.selected_option.get()
        self.current_response['is_correct'] = (self.selected_option.get() == self.questions[self.current_question][7])
    
    def next_question(self):
        """Move to the next question."""
        # Cancel the timer
        if self.timer_id:
            self.root.after_cancel(self.timer_id)
            self.timer_id = None
        
        # Record the response
        if self.current_response:
            self.current_response['time_taken'] = int(time.time() - self.current_response['time_started'])
            
            # If no option was selected, mark as incorrect
            if not self.current_response['user_answer']:
                self.current_response['user_answer'] = ""
                self.current_response['is_correct'] = False
            
            # Update score
            if self.current_response['is_correct']:
                self.score += 1
            
            # Add to responses
            self.responses.append(self.current_response)
        
        # Move to next question
        self.current_question += 1
        self.show_question()
    
    def end_exam(self):
        """End the exam and show results."""
        self.logger.info(f"Exam ended for {self.user['name']}, subject: {self.subject}")
        
        # Disable secure mode
        self.app.security_manager.disable_secure_mode()
        
        # Calculate total time taken
        total_time = int(time.time() - self.start_time)
        
        # Save result to database
        result_id = self.app.db.save_result(
            user_id=self.user['id'],
            usn=self.user['usn'],
            subject=self.subject,
            score=self.score,
            total=len(self.questions),
            duration=total_time
        )
        
        # Save detailed responses
        if result_id:
            self.app.db.save_user_responses(result_id, self.responses)
        
        # Prepare exam data for results screen
        exam_data = {
            'subject': self.subject,
            'total_questions': len(self.questions),
            'correct_answers': self.score,
            'duration': total_time,
            'responses': self.responses
        }
        
        # Show results screen
        self.app.show_results(exam_data=exam_data)