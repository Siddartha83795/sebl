import tkinter as tk
from tkinter import ttk, messagebox
from src.utils.logger import get_logger
from src.ui.components.animated import AnimatedLabel, create_fade_in_effect
from src.ui.components.glass_frame import GlassFrame

class LoginScreen:
    """Login screen for the application."""
    
    def __init__(self, root, app):
        self.logger = get_logger(__name__)
        self.root = root
        self.app = app
        self.frame = None
        
        # Initialize variables
        self.login_role = tk.StringVar(value="student")
        self.remember_me = tk.BooleanVar(value=False)
    
    def show(self):
        """Display the login screen."""
        self.logger.info("Showing login screen")
        
        # Create main frame
        self.frame = ttk.Frame(self.root)
        self.frame.pack(fill="both", expand=True)
        
        # Create a background with gradient
        theme = self.app.theme_manager.current_theme
        bg_gradient = self.app.theme_manager.create_gradient_canvas(
            self.frame, 
            self.root.winfo_width(), 
            self.root.winfo_height(),
            theme["bg"], 
            theme["accent"],
            "vertical"
        )
        bg_gradient.place(x=0, y=0, relwidth=1, relheight=1)
        
        # Logo and title container
        header_frame = GlassFrame(self.frame, opacity=0.1)
        header_frame.place(relx=0.5, rely=0.15, anchor="center", relwidth=0.8, height=120)
        
        # Create animated title
        logo_label = AnimatedLabel(
            header_frame, 
            text="SECURE MCQ 2025",
            font=("Roboto", 32, "bold"),
            foreground=theme["heading_fg"]
        )
        logo_label.pack(pady=20)
        logo_label.start_typing_animation(delay=50)
        
        # Subtitle
        subtitle = ttk.Label(
            header_frame,
            text="Advanced Assessment Platform",
            style="Subtext.TLabel",
            font=("Roboto", 14)
        )
        subtitle.pack()
        
        # Login form container
        login_container = GlassFrame(self.frame, opacity=0.2)
        login_container.place(relx=0.5, rely=0.5, anchor="center", relwidth=0.4, relheight=0.5)
        
        # Login form heading
        login_heading = ttk.Label(
            login_container, 
            text="Login to your account",
            style="Heading.TLabel"
        )
        login_heading.pack(pady=(30, 20))
        
        # Role selection
        role_frame = ttk.Frame(login_container)
        role_frame.pack(pady=10)
        
        # Student role button
        student_button = ttk.Radiobutton(
            role_frame, 
            text="Student", 
            variable=self.login_role,
            value="student",
            style="TRadiobutton"
        )
        student_button.pack(side=tk.LEFT, padx=15)
        
        # Staff role button
        staff_button = ttk.Radiobutton(
            role_frame, 
            text="Staff", 
            variable=self.login_role,
            value="staff",
            style="TRadiobutton"
        )
        staff_button.pack(side=tk.LEFT, padx=15)
        
        # Create form fields
        form_frame = ttk.Frame(login_container)
        form_frame.pack(pady=10, padx=40, fill="x")
        
        # USN/ID field
        ttk.Label(form_frame, text="USN/ID:").pack(anchor="w", pady=(10, 5))
        self.login_usn = ttk.Entry(form_frame, font=("Roboto", 12))
        self.login_usn.pack(fill="x", pady=(0, 10))
        
        # Password field
        ttk.Label(form_frame, text="Password:").pack(anchor="w", pady=(10, 5))
        self.login_pass = ttk.Entry(form_frame, show="•", font=("Roboto", 12))
        self.login_pass.pack(fill="x", pady=(0, 10))
        
        # Remember me checkbox
        remember_check = ttk.Checkbutton(
            form_frame, 
            text="Remember me", 
            variable=self.remember_me
        )
        remember_check.pack(anchor="w", pady=10)
        
        # Login button
        login_button = ttk.Button(
            login_container,
            text="Login",
            style="Primary.TButton",
            command=self.authenticate
        )
        login_button.pack(pady=20, ipadx=20, ipady=5)
        
        # Register option
        register_frame = ttk.Frame(login_container)
        register_frame.pack(pady=(0, 20))
        
        ttk.Label(
            register_frame, 
            text="Staff registration: "
        ).pack(side=tk.LEFT)
        
        register_link = ttk.Label(
            register_frame, 
            text="Register here",
            foreground=theme["accent"]
        )
        register_link.pack(side=tk.LEFT)
        register_link.bind("<Button-1>", lambda e: self.show_staff_registration())
        
        # Version info
        version_label = ttk.Label(
            self.frame, 
            text=f"Version {self.app.config.get('app', 'version')}",
            style="Subtext.TLabel",
            font=("Roboto", 8)
        )
        version_label.place(relx=0.99, rely=0.99, anchor="se", x=-10, y=-10)
        
        # Apply fade-in effect to the login container
        create_fade_in_effect(login_container)
        
        # Bind Enter key to authenticate
        self.root.bind("<Return>", lambda e: self.authenticate())
    
    def authenticate(self):
        """Authenticate user credentials."""
        usn = self.login_usn.get()
        password = self.login_pass.get()
        role = self.login_role.get()
        
        if not usn or not password:
            messagebox.showwarning("Input Error", "Please enter both USN/ID and password")
            return
        
        user = self.app.db.authenticate_user(usn, password, role)
        
        if user:
            self.logger.info(f"User authenticated: {user['name']}")
            self.app.set_current_user(user)
        else:
            self.logger.warning(f"Failed authentication attempt for USN: {usn}")
            messagebox.showerror("Authentication Failed", "Invalid credentials. Please try again.")
    
    def show_staff_registration(self):
        """Show staff registration form."""
        from src.ui.register import StaffRegistrationScreen
        registration = StaffRegistrationScreen(self.root, self.app)
        registration.show()