import tkinter as tk
from tkinter import messagebox
import keyboard
import socket
import threading
import time
from src.utils.logger import get_logger

class SecurityManager:
    """Manages security features for the exam environment."""
    
    def __init__(self, root):
        self.logger = get_logger(__name__)
        self.root = root
        self.exam_mode = False
        self.keyboard_blocked = False
        self.network_thread = None
        self.block_thread = None
    
    def enable_secure_mode(self):
        """
        Enable secure exam environment.
        Returns True if all security features were enabled successfully.
        """
        self.logger.info("Enabling secure mode")
        self.exam_mode = True
        success = True
        
        try:
            # Try to enable full screen
            if self.root.attributes('-fullscreen'):
                self.root.attributes('-fullscreen', True)
            else:
                # If full screen not supported, maximize window
                self.root.state('zoomed')
                success = False
                self.logger.warning("Fullscreen not supported, using maximized window instead")
        except:
            success = False
            self.logger.warning("Failed to set fullscreen mode")
        
        try:
            # Hide cursor
            self.root.config(cursor="none")
        except:
            success = False
            self.logger.warning("Failed to hide cursor")
        
        try:
            # Block keyboard shortcuts
            self.block_keyboard_shortcuts()
        except Exception as e:
            success = False
            self.logger.warning(f"Failed to block keyboard shortcuts: {str(e)}")
        
        try:
            # Start network monitoring
            self.start_network_monitoring()
        except Exception as e:
            success = False
            self.logger.warning(f"Failed to start network monitoring: {str(e)}")
        
        return success
    
    def disable_secure_mode(self):
        """Disable secure exam environment."""
        self.logger.info("Disabling secure mode")
        self.exam_mode = False
        
        # Restore window state
        self.root.attributes('-fullscreen', False)
        
        # Restore cursor
        self.root.config(cursor="")
        
        # Unblock keyboard shortcuts
        self.unblock_keyboard_shortcuts()
        
        # Stop network monitoring
        self.stop_network_monitoring()
    
    def block_keyboard_shortcuts(self):
        """Block system keyboard shortcuts."""
        if not self.keyboard_blocked:
            try:
                # Define keyboard combinations to block
                blocked_combos = [
                    'alt+tab', 'alt+f4', 'win+tab', 'win+d', 
                    'win+e', 'ctrl+esc', 'win+r', 'win+l'
                ]
                
                # Create a separate thread for keyboard blocking
                def block_keys():
                    for combo in blocked_combos:
                        keyboard.block_key(combo)
                    
                    # Block all key combinations with Win key
                    keyboard.block_key('win')
                    
                    # Block function keys
                    for i in range(1, 13):
                        keyboard.block_key(f'f{i}')
                    
                    while self.exam_mode:
                        time.sleep(0.1)
                
                self.block_thread = threading.Thread(target=block_keys, daemon=True)
                self.block_thread.start()
                
                self.keyboard_blocked = True
                self.logger.info("Keyboard shortcuts blocked")
            except Exception as e:
                self.logger.error(f"Failed to block keyboard shortcuts: {str(e)}")
                raise
    
    def unblock_keyboard_shortcuts(self):
        """Unblock system keyboard shortcuts."""
        if self.keyboard_blocked:
            try:
                keyboard.unhook_all()
                self.keyboard_blocked = False
                self.logger.info("Keyboard shortcuts unblocked")
            except Exception as e:
                self.logger.error(f"Failed to unblock keyboard shortcuts: {str(e)}")
    
    def start_network_monitoring(self):
        """Monitor network connections."""
        self.network_thread = threading.Thread(target=self.monitor_network, daemon=True)
        self.network_thread.start()
        self.logger.info("Network monitoring started")
    
    def stop_network_monitoring(self):
        """Stop network monitoring."""
        # The thread will exit when exam_mode is set to False
        self.logger.info("Network monitoring stopped")
    
    def monitor_network(self):
        """Check for active network connections."""
        while self.exam_mode:
            if self.check_internet():
                self.logger.warning("Internet connection detected during exam")
                # Show warning in the main thread
                self.root.after(0, lambda: self.show_network_warning())
            time.sleep(5)
    
    def check_internet(self):
        """Check internet connectivity."""
        try:
            # Try to connect to Google's DNS server
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            return True
        except OSError:
            return False
    
    def show_network_warning(self):
        """Show network warning message."""
        if self.exam_mode:
            messagebox.showwarning(
                "Network Warning",
                "Internet connection detected. Please disconnect to continue the exam."
            )
    
    def is_exam_mode(self):
        """Return whether exam mode is active."""
        return self.exam_mode
    
    def on_close_attempt(self):
        """Handle window close attempt."""
        if self.exam_mode:
            messagebox.showwarning("Warning", "Cannot close during exam!")
            return "break"  # Prevent window from closing
        return None  # Allow window to close