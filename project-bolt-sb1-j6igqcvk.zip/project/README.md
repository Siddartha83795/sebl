# Secure MCQ Testing Application 2025

A modern, secure multiple-choice question testing application with enhanced security features and a beautiful UI.

## Features

- **User Authentication**: Secure login system for students and staff
- **Modern UI/UX**: Beautiful 2025-style interface with glass morphism effects
- **Secure Exam Environment**: Keyboard blocking, network monitoring, and fullscreen mode
- **Question Management**: Create, import, and manage questions with Excel support
- **Student Management**: Add, import, and manage students with Excel support
- **Comprehensive Results**: Detailed exam results with analytics
- **Theme Support**: Dark and light mode themes

## Installation

1. Clone this repository:
   ```
   git clone https://github.com/yourusername/secure-mcq-2025.git
   cd secure-mcq-2025
   ```

2. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Run the application:
   ```
   python main.py
   ```

## Usage

### Staff Functions
- Add and manage questions individually or via Excel import
- Add and manage students individually or via Excel import
- View exam results and analytics

### Student Functions
- Take secure assessments in various subjects
- View personal exam results and performance history
- Track progress over time

## Project Structure

```
secure-mcq-2025/
├── main.py               # Application entry point
├── requirements.txt      # Dependencies
├── README.md             # Documentation
├── data/                 # Application data directory
│   └── secure_mcq.db     # SQLite database
├── logs/                 # Log files
│   └── mcq_app_*.log     # Daily log files
└── src/                  # Source code
    ├── core/             # Core application modules
    │   ├── app.py        # Main application class
    │   ├── config.py     # Configuration manager
    │   └── database.py   # Database operations
    ├── ui/               # User interface modules
    │   ├── components/   # Reusable UI components
    │   ├── login.py      # Login screen
    │   ├── register.py   # Registration screen
    │   ├── student_dashboard.py # Student dashboard
    │   ├── staff_dashboard.py   # Staff dashboard
    │   ├── exam.py       # Exam screen
    │   ├── results.py    # Results screen
    │   └── theme.py      # Theme manager
    └── utils/            # Utility modules
        ├── logger.py     # Logging utilities
        └── security.py   # Security features
```

## Excel Templates

### Question Import Template
Columns required:
- Subject
- Question
- Option A
- Option B
- Option C
- Option D
- Correct (A, B, C, or D)
- Image Path (optional)

### Student Import Template
Columns required:
- Name
- USN
- Section
- Password

## Security Features

- Keyboard shortcut blocking
- Internet connection monitoring
- Fullscreen mode
- Cursor hiding
- Alt+Tab prevention

## License

[MIT License](LICENSE)