import tkinter as tk
from tkinter import messagebox
import sys
import os

# Add the project directory to the path to allow imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import application modules
from src.core.app import SecureMCQApp
from src.utils.logger import setup_logger

def check_dependencies():
    """Check if all required dependencies are installed."""
    required_packages = [
        "pandas", "pillow", "keyboard", "openpyxl",
        "matplotlib", "ttkthemes", "ttkwidgets"
    ]
    
    missing_packages = []
    for package in required_packages:
        try:
            __import__(package)
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        message = "The following required packages are missing:\n"
        message += "\n".join(missing_packages)
        message += "\n\nWould you like to install them now?"
        
        if messagebox.askyesno("Missing Dependencies", message):
            try:
                import subprocess
                subprocess.check_call([
                    sys.executable, "-m", "pip", "install", *missing_packages
                ])
                messagebox.showinfo("Success", "Dependencies installed successfully. Please restart the application.")
            except Exception as e:
                messagebox.showerror("Installation Failed", f"Failed to install dependencies: {str(e)}")
            sys.exit()
        else:
            messagebox.showwarning("Warning", "Application may not function correctly without required dependencies.")
            return False
    return True

if __name__ == "__main__":
    # Setup logging
    logger = setup_logger()
    logger.info("Starting Secure MCQ 2025 Application")
    
    # Check dependencies before starting
    if check_dependencies():
        try:
            app = SecureMCQApp()
            app.start()
        except Exception as e:
            logger.error(f"Application error: {str(e)}")
            messagebox.showerror("Error", f"An unexpected error occurred: {str(e)}\n\nSee logs for details.")